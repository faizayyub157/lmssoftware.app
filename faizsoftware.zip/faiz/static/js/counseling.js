// static/js/counseling.js
$(document).ready(function() {
    console.log('🎯 COUNSELING SESSION FORM - INITIALIZED (Using studentlist method)');
    
    let ajaxCallCount = 0;

    // Load sections when school and class are selected
    function loadSections() {
        const schoolId = $('#schoolSelect').val();
        const studentClass = $('#classSelect').val();
        const callId = ++ajaxCallCount;
        
        console.log(`📞 [Call ${callId}] loadSections called`, {
            schoolId: schoolId,
            studentClass: studentClass,
            schoolText: $('#schoolSelect option:selected').text(),
            classText: $('#classSelect option:selected').text()
        });

        // Validate inputs
        if (!schoolId || !studentClass) {
            console.log(`⏸️ [Call ${callId}] Missing school or class, skipping AJAX`);
            updateSectionDropdown([], 'Please select both School and Class');
            return;
        }

        console.log(`🚀 [Call ${callId}] Making AJAX request using studentlist method...`);
        
        // Show loading state
        $('#sectionSelect').prop('disabled', false);
        $('#sectionSelect').html('<option value="">🔄 Loading sections...</option>');
        $('#sectionSelect').addClass('loading');

        // Make AJAX request
        $.ajax({
            url: $("#sectionSelect").data('ajax-url'), // Get URL from data attribute
            type: 'GET',
            data: {
                'school': schoolId,
                'student_class': studentClass
            },
            success: function(data) {
                console.log(`✅ [Call ${callId}] AJAX SUCCESS:`, data);
                $('#sectionSelect').removeClass('loading');

                if (data.success && data.sections && data.sections.length > 0) {
                    console.log(`🎉 [Call ${callId}] Found ${data.sections.length} sections:`, data.sections);
                    updateSectionDropdown(data.sections, 'Select Section');
                } else {
                    let errorMsg = 'No sections available';
                    if (data.error) {
                        errorMsg = 'Error: ' + data.error;
                        console.error(`❌ [Call ${callId}] Server error:`, data.error);
                    } else if (data.debug && data.debug.total_students === 0) {
                        errorMsg = 'No students found for this school and class';
                        console.warn(`⚠️ [Call ${callId}] No students in selected school/class`);
                    } else {
                        errorMsg = 'No sections defined for students in this class';
                        console.warn(`⚠️ [Call ${callId}] Students exist but no sections defined`);
                    }
                    updateSectionDropdown([], errorMsg);
                }
            },
            error: function(xhr, status, error) {
                console.error(`💥 [Call ${callId}] AJAX ERROR:`, {
                    status: status,
                    error: error,
                    responseText: xhr.responseText
                });
                $('#sectionSelect').removeClass('loading');
                updateSectionDropdown([], 'Error loading sections from server');
            },
            complete: function() {
                console.log(`🏁 [Call ${callId}] AJAX request completed`);
            }
        });
    }

    // Helper function to update section dropdown
    function updateSectionDropdown(sections, defaultText) {
        $('#sectionSelect').empty();
        
        if (sections.length > 0) {
            $('#sectionSelect').append(`<option value="">${defaultText}</option>`);
            sections.forEach(function(section) {
                $('#sectionSelect').append(`<option value="${section}">${section}</option>`);
            });
            $('#sectionSelect').prop('disabled', false);
            console.log(`✅ Updated dropdown with ${sections.length} sections`);
        } else {
            $('#sectionSelect').append(`<option value="">${defaultText}</option>`);
            $('#sectionSelect').prop('disabled', false);
            console.log(`ℹ️ Updated dropdown with message: ${defaultText}`);
        }
    }

    // Event handlers
    $('#schoolSelect').change(function() {
        const schoolId = $(this).val();
        const schoolName = $('#schoolSelect option:selected').text();
        console.log('🏫 School changed:', { id: schoolId, name: schoolName });
        loadSections();
    });

    $('#classSelect').change(function() {
        const classVal = $(this).val();
        const className = $('#classSelect option:selected').text();
        console.log('📚 Class changed:', { value: classVal, name: className });
        loadSections();
    });

    // Form validation
    $('#sessionForm').submit(function(e) {
        const school = $('#schoolSelect').val();
        const studentClass = $('#classSelect').val();
        const section = $('#sectionSelect').val();
        
        console.log('📝 Form submission check:', {school, studentClass, section});
        
        if (!school || !studentClass || !section) {
            e.preventDefault();
            let errorMessage = 'Please select ';
            const missing = [];
            if (!school) missing.push('School');
            if (!studentClass) missing.push('Class');
            if (!section) missing.push('Section');
            errorMessage += missing.join(', ');
            
            console.log('❌ Form validation failed:', errorMessage);
            alert('❌ ' + errorMessage);
            return false;
        }
        
        console.log('✅ Form validation passed');
    });

    // Initialize only if the form exists on this page
    if ($('#sessionForm').length) {
        console.log('🎬 Initializing counseling form...');
        loadSections();
        console.log('🎉 Counseling form initialization complete');
    }
});