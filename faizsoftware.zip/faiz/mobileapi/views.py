from rest_framework.decorators import api_view
from rest_framework.response import Response
from student.models import student, Exam, Homework, VideoTutorial, NotificationReceipt


# ================= LOGIN ==================
@api_view(['POST'])
def mobile_login(request):
    email = request.data.get('email')
    password = request.data.get('password')

    try:
        s = student.objects.get(email=email)
        if s.check_password(password):
            return Response({
                "status": "ok",
                "student_id": s.id,
                "name": s.name,
                "class": s.student_class,
                "school": s.school.name
            })
    except:
        pass
    return Response({"status": "fail"})


# ================= DASHBOARD ==================
@api_view(['GET'])
def mobile_dashboard(request):
    sid = request.GET.get('student_id')
    s = student.objects.get(id=sid)

    return Response({
        "name": s.name,
        "class": s.student_class,
        "school": s.school.name,
        "total_exams": Exam.objects.filter(student_class=s.student_class, school=s.school).count(),
        "pending_homework": Homework.objects.filter(student_class=s.student_class, school=s.school).count()
    })


# ================= EXAMS ==================
@api_view(['GET'])
def mobile_exams(request):
    sid = request.GET.get('student_id')
    s = student.objects.get(id=sid)

    return Response(list(
        Exam.objects.filter(student_class=s.student_class, school=s.school)
        .values('id','title','exam_date','total_marks')
    ))


# ================= HOMEWORK ==================
@api_view(['GET'])
def mobile_homework(request):
    sid = request.GET.get('student_id')
    s = student.objects.get(id=sid)

    return Response(list(
        Homework.objects.filter(student_class=s.student_class, school=s.school)
        .values('chapter__title','due_date')
    ))


# ================= VIDEOS ==================
@api_view(['GET'])
def mobile_videos(request):
    return Response(list(VideoTutorial.objects.values('title','video_url','description')))


# ================= NOTIFICATIONS ==================
@api_view(['GET'])
def mobile_notifications(request):
    sid = request.GET.get('student_id')
    return Response(list(
        NotificationReceipt.objects.filter(recipient_object_id=sid)
        .values('notification__title','notification__message','is_read','created_at')
    ))
