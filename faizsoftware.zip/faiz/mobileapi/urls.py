from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.mobile_login),
    path('dashboard/', views.mobile_dashboard),
    path('exams/', views.mobile_exams),
    path('homework/', views.mobile_homework),
    path('videos/', views.mobile_videos),
    path('notifications/', views.mobile_notifications),
]
