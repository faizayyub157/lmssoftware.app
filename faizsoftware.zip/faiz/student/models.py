from django.db import models
from django.contrib.auth.hashers import make_password, check_password
from django.utils.timezone import now
from django.utils import timezone  # Added this import to fix the timezone error
import uuid
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import check_password
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from decimal import Decimal
from django.core.validators import FileExtensionValidator
import calendar
from django.db import transaction




# Choices for class selection
CLASS_CHOICES = [
    ('Class 1', 'Class 1'),
    ('Class 2', 'Class 2'),
    ('Class 3', 'Class 3'),
    ('Class 4', 'Class 4'),
    ('Class 5', 'Class 5'),
    ('Class 6', 'Class 6'),
    ('Class 7', 'Class 7'),
    ('Class 8', 'Class 8'),
    ('Class 9', 'Class 9'),
    ('Class 10', 'Class 10'),
    ('General', 'General'),
]
class Module(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name

class UserRole(models.TextChoices):
    STUDENT = "student", "Student"
    TEACHER = "teacher", "Teacher"
    SCHOOL = "school", "School"
    SUPER_ADMIN = "super_admin", "Super Admin"

class UserAccess(models.Model):
    role = models.CharField(max_length=15, choices=UserRole.choices)
    modules = models.ManyToManyField(Module)

    def __str__(self):
        return f"{self.get_role_display()}"
# -------------------------
# New Models for School and Trainer
# -------------------------
class School(models.Model):
    name = models.CharField(max_length=255, unique=True)
    appointed_trainer = models.ForeignKey(
        'Trainer',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_schools',
        help_text="Trainer appointed to this school"
    )
    payment_due = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0.00,
        help_text="Total payment due for the school"
    )
    monthly_fee = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0.00,
        help_text="Monthly fee amount"
    )
    address = models.CharField(max_length=255, blank=True, null=True)
    contact_number = models.CharField(max_length=15, blank=True, null=True)
    role = models.ForeignKey(UserAccess, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return self.name

class Trainer(models.Model):
    name = models.CharField(max_length=255)
    qualification = models.CharField(max_length=255)
    daily_update = models.TextField(blank=True, null=True, help_text="Daily update from trainer")
    salary = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    profile_image = models.ImageField(upload_to='profileimage/', blank=True, null=True)
    joining_date = models.DateField()
    remaining_due = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    assigned_school = models.ForeignKey(
        School,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='trainers',
        help_text="School where the trainer is assigned"
    )
    email = models.EmailField(unique=True, blank=True, null=True)
    phone = models.CharField(max_length=15, blank=True, null=True)
    role = models.ForeignKey(UserAccess, on_delete=models.SET_NULL, null=True, blank=True)
    password = models.CharField(max_length=128, help_text="Hashed password for authentication")

    def save(self, *args, **kwargs):
        if self.password and not self.password.startswith('pbkdf2_sha256$'):
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.name} - {self.qualification}"
    
    def check_password(self, raw_password):
        """Verify hashed password matches the raw password"""
        return check_password(raw_password, self.password)

class student(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    enrollment = models.CharField(max_length=100)
    profile_image = models.ImageField(upload_to='profileimage/', blank=True, null=True)
    course = models.CharField(max_length=100)
    dob = models.DateField()
    enrollment_date = models.DateField()
    student_class = models.CharField(max_length=100, choices=CLASS_CHOICES, default="General")
    section = models.CharField(max_length=50, blank=True, null=True)  # <-- Added field
    school = models.ForeignKey(
        School,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='students'
    )

    def save(self, *args, **kwargs):
        if not self.password.startswith('pbkdf2_sha256$'):
            self.password = make_password(self.password)
        super().save(*args, **kwargs)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return self.name



class UserProfile(models.Model):
    # Link to either Student or Trainer (only one should be set)
    student = models.OneToOneField(
        student, 
        on_delete=models.CASCADE, 
        null=True, 
        blank=True,
        related_name='profile'
    )
    trainer = models.OneToOneField(
        Trainer, 
        on_delete=models.CASCADE, 
        null=True, 
        blank=True,
        related_name='profile'
    )
    
    # Fields from settings.html that are missing in both models
    cover_image = models.ImageField(upload_to='cover_images/', blank=True, null=True)
    first_name = models.CharField(max_length=100, blank=True, null=True)
    last_name = models.CharField(max_length=100, blank=True, null=True)
    phone = models.CharField(max_length=15, blank=True, null=True)
    zip_code = models.CharField(max_length=10, blank=True, null=True)
    bio = models.TextField(blank=True, null=True)  # Changed from RichTextField to TextField
    
    # Social media links
    facebook_url = models.URLField(blank=True, null=True)
    twitter_url = models.URLField(blank=True, null=True)
    linkedin_url = models.URLField(blank=True, null=True)
    instagram_url = models.URLField(blank=True, null=True)
    
    # Additional contact information
    secondary_phone = models.CharField(max_length=15, blank=True, null=True)
    secondary_email = models.EmailField(blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    
    # Statistics (could be auto-calculated or manually entered)
    followers_count = models.PositiveIntegerField(default=0)
    following_count = models.PositiveIntegerField(default=0)
    likes_count = models.PositiveIntegerField(default=0)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        constraints = [
            models.CheckConstraint(
                check=models.Q(student__isnull=False) | models.Q(trainer__isnull=False),
                name='at_least_one_user_type'
            ),
            models.UniqueConstraint(
                fields=['student'],
                condition=models.Q(student__isnull=False),
                name='unique_student_profile'
            ),
            models.UniqueConstraint(
                fields=['trainer'],
                condition=models.Q(trainer__isnull=False),
                name='unique_trainer_profile'
            )
        ]
    
    def __str__(self):
        if self.student:
            return f"Profile for {self.student.name}"
        elif self.trainer:
            return f"Profile for {self.trainer.name}"
        return "User Profile (no user)"
    
    def get_user(self):
        """Return the associated user regardless of type"""
        return self.student or self.trainer
    
    def get_user_type(self):
        """Return the type of user"""
        if self.student:
            return 'Student'
        elif self.trainer:
            return 'Trainer'
        return 'Unknown'
    
    def save(self, *args, **kwargs):
        # Ensure only one of student or trainer is set
        if self.student and self.trainer:
            raise ValueError("Profile can only be associated with either a student OR a trainer, not both.")
        super().save(*args, **kwargs)

class ObjectiveQuestion(models.Model):
    question_text = models.TextField()
    option1 = models.CharField(max_length=255)
    option2 = models.CharField(max_length=255)
    option3 = models.CharField(max_length=255)
    option4 = models.CharField(max_length=255)
    correct_answer = models.CharField(max_length=255)

    def __str__(self):
        return self.question_text

class Chapter(models.Model):
    STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    ]
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_started')
    student_class = models.CharField(max_length=100, choices=CLASS_CHOICES, default="General")

    def __str__(self):
        return f"{self.title} - {self.get_status_display()}"

class Exam(models.Model):
    duration_minutes = models.IntegerField(default=30)
    title = models.CharField(max_length=255)
    subject = models.CharField(max_length=255)
    total_marks = models.IntegerField()
    marks_per_question = models.IntegerField(default=1)
    exam_date = models.DateField()
    student_class = models.CharField(max_length=100, choices=CLASS_CHOICES, default="General")
    # New field to associate Exam with a School. This will show a dropdown in the admin.
    school = models.ForeignKey(
        School,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='exams',
        help_text="School to which this exam is assigned"
    )

    def __str__(self):
        return self.title

class ExamQuestion(models.Model):
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE)
    question_text = models.TextField()
    option_a = models.CharField(max_length=255)
    option_b = models.CharField(max_length=255)
    option_c = models.CharField(max_length=255)
    option_d = models.CharField(max_length=255)
    correct_answer = models.CharField(max_length=1, choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')])

    def __str__(self):
        return f"{self.exam.title} - {self.question_text}"

class StudentExamPerformance(models.Model):
    student = models.ForeignKey(student, on_delete=models.CASCADE)
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE)
    marks_obtained = models.IntegerField()
    test_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student.name} - {self.exam.title} ({self.marks_obtained}/{self.exam.total_marks})"

class StudentProgress(models.Model):
    student = models.OneToOneField(student, on_delete=models.CASCADE)
    total_tests = models.IntegerField(default=0)
    avg_marks = models.FloatField(default=0.0)
    last_exam_date = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.student.name} - Progress"

class StudentProject(models.Model):
    student = models.ForeignKey(student, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True, null=True)
    file = models.FileField(upload_to='projects/')
    submitted_at = models.DateTimeField(auto_now_add=True)
    is_approved = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.student.name} - {self.title}"

# -------------------------
# Corrected StudentExamResponse Model
# -------------------------
class StudentExamResponse(models.Model):
    """
    This model stores the response for each exam question answered (or not answered)
    by a student during an exam attempt.
    """
    RESULT_CHOICES = [
        ('C', 'Correct'),
        ('I', 'Incorrect'),
        ('U', 'Unanswered'),
    ]
    student_exam_performance = models.ForeignKey(
        StudentExamPerformance,
        on_delete=models.CASCADE,
        related_name='responses'
    )
    exam_question = models.ForeignKey(
        ExamQuestion,
        on_delete=models.CASCADE,
        related_name='student_responses'
    )
    selected_answer = models.CharField(
        max_length=1,
        choices=[('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D')],
        blank=True,
        null=True,
        help_text="The option selected by the student. Leave blank if not answered."
    )
    result = models.CharField(
        max_length=1,
        choices=RESULT_CHOICES,
        default='U'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Exam Response'
        verbose_name_plural = 'Exam Responses'

    def __str__(self):
        student_name = self.student_exam_performance.student.name
        question_snippet = self.exam_question.question_text[:50]
        return f"{student_name} - {question_snippet}"

    def is_correct(self):
        if not self.selected_answer:
            return None
        return self.selected_answer == self.exam_question.correct_answer

    def get_result_display(self):
        if not self.selected_answer:
            return "Not Answered"
        elif self.selected_answer == self.exam_question.correct_answer:
            return "Correct"
        else:
            return "Wrong"

    def get_question_text(self):
        return self.exam_question.question_text

    def get_exam_title(self):
        return self.exam_question.exam.title

    def get_correct_answer(self):
        return self.exam_question.correct_answer

class Discussion(models.Model):
    student = models.ForeignKey(student, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.student.name}: {self.content[:50]}"

    @property
    def likes_count(self):
        return self.likes.count()

    @property
    def comments_count(self):
        return self.comments.count()

class Comment(models.Model):
    student = models.ForeignKey(student, on_delete=models.CASCADE)
    discussion = models.ForeignKey(Discussion, on_delete=models.CASCADE, related_name='comments')
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"{self.student.name}: {self.content[:50]}"

class DiscussionLike(models.Model):
    student = models.ForeignKey(student, on_delete=models.CASCADE)
    discussion = models.ForeignKey(Discussion, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('student', 'discussion')

    def __str__(self):
        return f"{self.student.name} liked {self.discussion.content[:50]}"

class Homework(models.Model):
    STATUS_CHOICES = [
        ('assigned', 'Assigned'),
        ('in_progress', 'In Progress'),
        ('submitted', 'Submitted'),
        ('completed', 'Completed'),
        ('overdue', 'Overdue'),
    ]
    student_class = models.CharField(max_length=100, choices=CLASS_CHOICES, default="General")
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE)
    assigned_date = models.DateTimeField(auto_now_add=True)
    due_date = models.DateTimeField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='assigned')
    description = models.TextField(blank=True, null=True)
    submission_file = models.FileField(upload_to='homework_submissions/', blank=True, null=True)
    submitted_date = models.DateTimeField(blank=True, null=True)
    marks = models.IntegerField(blank=True, null=True)
    feedback = models.TextField(blank=True, null=True)
    is_group_assignment = models.BooleanField(default=False, help_text="Check if this homework is a group assignment.")
    # New fields referencing School and Trainer
    school = models.ForeignKey(
        School,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='homeworks',
        help_text="School for which the homework is assigned"
    )
    trainer = models.ForeignKey(
        Trainer,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='homeworks',
        help_text="Trainer who assigned the homework"
    )

    def __str__(self):
        school_name = self.school.name if self.school else "No School"
        trainer_name = self.trainer.name if self.trainer else "No Trainer"
        return f"{self.chapter.title} for {school_name} (Trainer: {trainer_name})"

    class Meta:
        ordering = ['-assigned_date']
        verbose_name = 'Homework Assignment'
        verbose_name_plural = 'Homework Assignments'

class StudentRecentActivity(models.Model):
    student = models.OneToOneField(student, on_delete=models.CASCADE, related_name='recent_activity')
    last_login = models.DateTimeField(default=now, help_text="The last time the student logged in.")
    profile_updated_at = models.DateTimeField(blank=True, null=True, help_text="The last time the student updated their profile.")

    def update_last_login(self):
        self.last_login = now()
        self.save()

    def update_profile_timestamp(self):
        self.profile_updated_at = now()
        self.save()

    def __str__(self):
        return f"{self.student.name} - Last Login: {self.last_login}, Profile Updated: {self.profile_updated_at}"

class LiveClassRoom(models.Model):
    # Change host to GenericForeignKey to support multiple user types
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    host = GenericForeignKey('content_type', 'object_id')
    # Rest of the fields remain the same
    room_id = models.CharField(max_length=100, unique=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    participants = models.ManyToManyField(student, related_name='joined_rooms', blank=True)

    def __str__(self):
        return f"Room {self.room_id}"

class VideoTutorial(models.Model):
    chapter = models.ForeignKey(
        Chapter,
        on_delete=models.CASCADE,
        related_name='video_tutorials',
        help_text="Select the chapter (category) for this video tutorial"
    )
    title = models.CharField(max_length=255)
    video_url = models.URLField(
        help_text="Enter the YouTube embed URL (or other video URL) for this tutorial"
    )
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.chapter.title} - {self.chapter.student_class})"

class Project(models.Model):
    student = models.ForeignKey(student, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    description = models.TextField()
    file = models.FileField(upload_to='projects/')
    submitted_at = models.DateTimeField(auto_now_add=True)
    likes = models.ManyToManyField(User, related_name='liked_projects', blank=True)

    def total_likes(self):
        return self.likes.count()

    def __str__(self):
        return self.title

class Commentproject(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(Trainer, on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Comment by {self.user.name} on {self.project.title}'

class Certificate(models.Model):
    ACHIEVEMENT_CHOICES = (
        ('excellence', 'Excellence'),
        ('participation', 'Participation'),
        ('merit', 'Merit'),
    )

    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('issued', 'Issued'),
        ('rejected', 'Rejected'),
    )

    student = models.ForeignKey(student, on_delete=models.CASCADE, related_name='certificates')
    achievement = models.CharField(max_length=20, choices=ACHIEVEMENT_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    request_date = models.DateTimeField(default=timezone.now)
    issued_date = models.DateTimeField(null=True, blank=True)
    certificate_number = models.CharField(max_length=100, unique=True, blank=True, null=True)

    def __str__(self):
        return f"Certificate for {self.student.name} in {self.student.course}"

    def save(self, *args, **kwargs):
        if not self.certificate_number:
            self.certificate_number = f"CERT-{self.student.id}-{int(timezone.now().timestamp())}"
        super().save(*args, **kwargs)


class Resource(models.Model):
    # Link to a chapter so you can display the chapter topic.
    chapter = models.ForeignKey(
        'Chapter', 
        on_delete=models.CASCADE, 
        related_name='resources',
        help_text="Select the chapter for this resource"
    )
    # Optionally link to a school if needed.
    school = models.ForeignKey(
        'School',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='resources',
        help_text="Select the school (if applicable) for this resource"
    )
    title = models.CharField(
        max_length=255,
        help_text="Title of the resource"
    )
    description = models.TextField(
        blank=True,
        null=True,
        help_text="Optional description for this resource"
    )
    # Attached PDF file.
    pdf = models.FileField(
        upload_to='resources/',
        help_text="Upload the PDF file for this resource"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
    
class HomeworkSubmission(models.Model):
    student = models.ForeignKey(
        student, 
        on_delete=models.CASCADE, 
        related_name='submissions',
        help_text="Student who submitted the homework"
    )
    homework = models.ForeignKey(
        Homework, 
        on_delete=models.CASCADE, 
        related_name='submissions',
        help_text="Homework assignment being submitted"
    )
    submission_file = models.FileField(
        upload_to='homework_submissions/',
        blank=False,
        null=False,
        help_text="File submitted by the student"
    )
    submitted_date = models.DateTimeField(default=now, help_text="Date and time of submission")
    marks_obtained = models.IntegerField(blank=True, null=True, help_text="Marks awarded for the submission")
    feedback = models.TextField(blank=True, null=True, help_text="Teacher's feedback on the submission")

    def __str__(self):
        return f"{self.student.name} - {self.homework.chapter.title} Submission"

    class Meta:
        ordering = ['-submitted_date']
        verbose_name = 'Homework Submission'
        verbose_name_plural = 'Homework Submissions'

class DailyTaskUpdate(models.Model):
    STATUS_CHOICES = [
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('holiday', 'Holiday'),
        ('requested', 'Requested Update'),
    ]

    trainer = models.ForeignKey(
        Trainer,
        on_delete=models.CASCADE,
        related_name='daily_updates',
        help_text="Trainer who submitted the update"
    )
    date = models.DateField(
        default=timezone.now,
        help_text="Date for which the update is being submitted"
    )
    update_text = models.TextField(
        blank=True,
        null=True,
        help_text="Detailed description of daily tasks"
    )
    update_image = models.ImageField(
        upload_to='daily_updates/',
        blank=True,
        null=True,
        help_text="Optional image attachment for the update"
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='present',
        help_text="Status of the trainer for this day"
    )
    submission_time = models.DateTimeField(
        auto_now_add=True,
        help_text="Time when the update was submitted"
    )
    is_requested_update = models.BooleanField(
        default=False,
        help_text="Whether this is a requested update for a past date"
    )
    is_approved = models.BooleanField(
        default=False,
        help_text="Whether the update has been approved by admin (for requested updates)"
    )

    class Meta:
        unique_together = ('trainer', 'date')
        ordering = ['-date']
        verbose_name = 'Daily Task Update'
        verbose_name_plural = 'Daily Task Updates'

    def __str__(self):
        return f"{self.trainer.name} - {self.date} ({self.get_status_display()})"

    def is_holiday(self):
        return self.status == 'holiday'

    def is_weekend(self):
        return self.date.weekday() >= 5  # 5=Saturday, 6=Sunday

    def get_update_time(self):
        return self.submission_time.strftime("%I:%M %p")

class Salary(models.Model):
    STATUS_CHOICES = [
        ('paid', 'Paid'),
        ('pending', 'Pending'),
        ('overdue', 'Overdue'),
    ]
    
    trainer = models.ForeignKey(
        'Trainer',
        on_delete=models.CASCADE,
        related_name='salaries'
    )
    month = models.DateField(help_text="Select month and year for salary calculation")
    present_days = models.PositiveIntegerField(default=0)
    basic = models.DecimalField(max_digits=10, decimal_places=2, default=0)  # Monthly full basic salary
    prorated_basic = models.DecimalField(max_digits=10, decimal_places=2, default=0)  # Based on present days

    hra = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    allowances = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    tax = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    pf = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    other_deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    net_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    payment_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('trainer', 'month')
        ordering = ['-month']
        verbose_name_plural = 'Salaries'

    def save(self, *args, **kwargs):
        if not self.pk:
            self.refresh_attendance_and_recalculate()
        else:
            # Just recalculate amounts if already created and values changed
            self.calculate_salary()

        super().save(*args, **kwargs)

    def refresh_attendance_and_recalculate(self):
        # Set present days from DailyTaskUpdate
        start_date = self.month.replace(day=1)
        last_day = calendar.monthrange(self.month.year, self.month.month)[1]
        end_date = self.month.replace(day=last_day)

        self.present_days = DailyTaskUpdate.objects.filter(
            trainer=self.trainer,
            date__gte=start_date,
            date__lte=end_date,
            status='present'
        ).count()

        self.calculate_salary()

    def calculate_salary(self):
        # Set full monthly basic from trainer
        self.basic = Decimal(self.trainer.salary)

        # Calculate prorated basic
        days_in_month = calendar.monthrange(self.month.year, self.month.month)[1]
        self.prorated_basic = (self.basic / Decimal(days_in_month)) * Decimal(self.present_days)

        # Calculate net_salary
        gross = self.prorated_basic + self.hra + self.allowances
        total_deductions = self.tax + self.pf + self.other_deductions
        self.net_salary = gross - total_deductions

    def __str__(self):
        return f"{self.trainer.name} - {self.month.strftime('%B %Y')} - ₹{self.net_salary:.2f}"

    @property
    def gross_salary(self):
        return self.prorated_basic + self.hra + self.allowances

    @property
    def total_deductions(self):
        return self.tax + self.pf + self.other_deductions

class DocumentType(models.Model):
    DOCUMENT_CATEGORIES = [
        ('education', 'Education'),
        ('identity', 'Identity Proof'),
        ('financial', 'Financial'),
        ('other', 'Other'),
    ]
    
    id = models.CharField(max_length=50, primary_key=True)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    is_required = models.BooleanField(default=True)
    category = models.CharField(max_length=20, choices=DOCUMENT_CATEGORIES, default='other')
    
    class Meta:
        verbose_name = 'Document Type'
        verbose_name_plural = 'Document Types'
        ordering = ['name']
    
    def __str__(self):
        return f"{self.name} ({'Required' if self.is_required else 'Optional'})"


class DocumentField(models.Model):
    FIELD_TYPES = [
        ('text', 'Text'),
        ('number', 'Number'),
        ('date', 'Date'),
        ('select', 'Dropdown Select'),
    ]
    
    document_type = models.ForeignKey(
        DocumentType,
        on_delete=models.CASCADE,
        related_name='fields'
    )
    name = models.CharField(max_length=100)
    label = models.CharField(max_length=255)
    field_type = models.CharField(max_length=20, choices=FIELD_TYPES)
    is_required = models.BooleanField(default=True)
    pattern = models.CharField(max_length=100, blank=True, null=True)
    min_value = models.IntegerField(blank=True, null=True)
    max_value = models.IntegerField(blank=True, null=True)
    options = models.JSONField(default=list, blank=True)
    
    class Meta:
        ordering = ['id']
        verbose_name = 'Document Field'
        verbose_name_plural = 'Document Fields'
    
    def __str__(self):
        return f"{self.document_type.name} - {self.label}"


class TrainerDocument(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('submitted', 'Submitted'),
        ('verified', 'Verified'),
        ('rejected', 'Rejected'),
    ]
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    trainer = models.ForeignKey(
        'Trainer', 
        on_delete=models.CASCADE, 
        related_name='documents'
    )
    document_type = models.ForeignKey(DocumentType, on_delete=models.PROTECT)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    submitted_at = models.DateTimeField(auto_now_add=True)
    verified_at = models.DateTimeField(null=True, blank=True)
    verified_by = models.ForeignKey(
        'auth.User', 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True, 
        related_name='verified_documents'
    )
    rejection_reason = models.TextField(blank=True)
    document_file = models.FileField(
        upload_to='trainer_documents/%Y/%m/%d/',
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'jpg', 'jpeg', 'png'])]
    )
    # Add this field to store form data
    form_data = models.JSONField(default=dict, blank=True)
    
    class Meta:
        ordering = ['-submitted_at']
        unique_together = ['trainer', 'document_type']
        verbose_name = 'Trainer Document'
        verbose_name_plural = 'Trainer Documents'
    
    def __str__(self):
        return f"{self.trainer.name} - {self.document_type.name} ({self.get_status_display()})"
    
    def save(self, *args, **kwargs):
        if self.status == 'verified' and not self.verified_at:
            self.verified_at = timezone.now()
        super().save(*args, **kwargs)
    
    @property
    def is_complete(self):
        return self.status in ['submitted', 'verified']


class DocumentUploadProgress(models.Model):
    trainer = models.OneToOneField(
        'Trainer',
        on_delete=models.CASCADE,
        related_name='document_progress'
    )
    required_documents_count = models.PositiveIntegerField(default=0)
    completed_documents_count = models.PositiveIntegerField(default=0)
    last_updated = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = 'Document Upload Progress'
        verbose_name_plural = 'Document Upload Progress'
    
    def __str__(self):
        return f"Progress for {self.trainer.name}"
    
    @property
    def completion_percentage(self):
        if self.required_documents_count == 0:
            return 0
        return int((self.completed_documents_count / self.required_documents_count) * 100)
    
    def update_progress(self):
        # Count required document types
        required_types_qs = DocumentType.objects.filter(is_required=True)
        self.required_documents_count = required_types_qs.count()

        # Count distinct required document types that the trainer has submitted/verified
        completed_count = TrainerDocument.objects.filter(
            trainer=self.trainer,
            status__in=['submitted', 'verified'],
            document_type__in=required_types_qs
        ).values('document_type').distinct().count()

        self.completed_documents_count = completed_count
        # Use transaction to be safer in concurrent scenarios
        with transaction.atomic():
            self.save()
    
    def get_progress_display(self):
        return f"{self.completed_documents_count}/{self.required_documents_count} ({self.completion_percentage}%)"    

# Add to your models.py

class UserNote(models.Model):
    user = models.ForeignKey(
        student, 
        on_delete=models.CASCADE, 
        related_name='notes'
    )
    chapter = models.ForeignKey(
        Chapter, 
        on_delete=models.CASCADE, 
        related_name='user_notes'
    )
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['user', 'chapter']
        ordering = ['-updated_at']
    
    def __str__(self):
        return f"Note by {self.user.name} on {self.chapter.title}"

class ChapterProgress(models.Model):
    STATUS_CHOICES = [
        ('not_started', 'Not Started'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
    ]
    
    user = models.ForeignKey(
        student, 
        on_delete=models.CASCADE, 
        related_name='chapter_progress'
    )
    chapter = models.ForeignKey(
        Chapter, 
        on_delete=models.CASCADE, 
        related_name='user_progress'
    )
    status = models.CharField(
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='not_started'
    )
    last_read = models.DateTimeField(auto_now=True)
    is_bookmarked = models.BooleanField(default=False)
    
    class Meta:
        unique_together = ['user', 'chapter']
        verbose_name_plural = 'Chapter progress records'
    
    def __str__(self):
        return f"{self.user.name} - {self.chapter.title} ({self.status})"
    
# Add these models to your existing models.py file

class CounselingSession(models.Model):
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('locked', 'Locked'),
    ]
    
    counselor = models.ForeignKey(
        'Trainer',
        on_delete=models.CASCADE,
        related_name='counseling_sessions'
    )
    school = models.ForeignKey(
        'School',
        on_delete=models.CASCADE,
        related_name='counseling_sessions'
    )
    date_of_session = models.DateField(default=timezone.now)
    student_class = models.CharField(max_length=100, choices=CLASS_CHOICES)
    section = models.CharField(max_length=50)
    session_notes = models.TextField(blank=True, null=True, help_text="General notes for this counseling session")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    locked_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        verbose_name = 'Counseling Session'
        verbose_name_plural = 'Counseling Sessions'
        ordering = ['-date_of_session', '-created_at']
    
    def __str__(self):
        return f"Session {self.id} - {self.school.name} - {self.date_of_session}"
    
    def lock_session(self):
        """Lock the counseling session"""
        self.status = 'locked'
        self.locked_at = timezone.now()
        self.save()
    
    def unlock_session(self):
        """Unlock the counseling session"""
        self.status = 'completed'
        self.locked_at = None
        self.save()
    
    def get_students_count(self):
        return self.student_counselings.count()
    
    def is_locked(self):
        return self.status == 'locked'

class StudentCounselingRecord(models.Model):  # Changed name to avoid conflict
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]
    
    INTEREST_LEVEL_CHOICES = [
        (1, '1 - Very Low'),
        (2, '2 - Low'),
        (3, '3 - Moderate'),
        (4, '4 - High'),
        (5, '5 - Very High'),
    ]
    
    YES_NO_CHOICES = [
        ('Y', 'Yes'),
        ('N', 'No'),
    ]
    
    # Session reference
    counseling_session = models.ForeignKey(
        CounselingSession,
        on_delete=models.CASCADE,
        related_name='student_counselings'
    )
    
    # Student information
    student = models.ForeignKey(
        'student',
        on_delete=models.CASCADE,
        related_name='counseling_records'
    )
    
    # Counseling details
    interested_in_robotics = models.CharField(
        max_length=1,
        choices=YES_NO_CHOICES,
        blank=True,
        null=True
    )
    
    interest_level = models.IntegerField(
        choices=INTEREST_LEVEL_CHOICES,
        blank=True,
        null=True
    )
    
    favorite_subject = models.CharField(
        max_length=100,
        blank=True,
        null=True
    )
    
    career_aspiration = models.TextField(
        blank=True,
        null=True
    )
    
    parent_involvement = models.CharField(
        max_length=1,
        choices=YES_NO_CHOICES,
        blank=True,
        null=True
    )
    
    parent_feedback = models.TextField(
        blank=True,
        null=True
    )
    
    student_feedback = models.TextField(
        blank=True,
        null=True
    )
    
    counselor_notes = models.TextField(
        blank=True,
        null=True
    )
    
    contact_number = models.CharField(
        max_length=15,
        blank=True,
        null=True
    )
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'Student Counseling Record'
        verbose_name_plural = 'Student Counseling Records'
        unique_together = ['counseling_session', 'student']
        ordering = ['student__name']

    def __str__(self):
        return f"{self.student.name} - {self.counseling_session.date_of_session}"

    def save(self, *args, **kwargs):
        # Auto-populate contact number from student if available
        if not self.contact_number:
            # Try to get contact from student profile
            try:
                if hasattr(self.student, 'profile') and self.student.profile.phone:
                    self.contact_number = self.student.profile.phone
            except:
                pass
        super().save(*args, **kwargs)

    def get_student_age(self):
        """Calculate student's age"""
        if self.student.dob:
            today = self.counseling_session.date_of_session
            return today.year - self.student.dob.year - ((today.month, today.day) < (self.student.dob.month, self.student.dob.day))
        return None
    
# Add this to your models.py file
class Notification(models.Model):
    NOTIFICATION_TYPES = [
        ('homework', 'Homework'),
        ('exam', 'Exam'),
        ('project', 'Project'),
        ('certificate', 'Certificate'),
        ('salary', 'Salary'),
        ('attendance', 'Attendance'),
        ('general', 'General'),
        ('counseling', 'Counseling'),
        ('resource', 'Resource'),
        ('system', 'System'),
    ]
    
    PRIORITY_CHOICES = [
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    ]

    # Notification content
    title = models.CharField(max_length=255)
    message = models.TextField()
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES, default='general')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    
    # Sender information (can be trainer, system, or null for automated)
    sender_content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True, blank=True)
    sender_object_id = models.PositiveIntegerField(null=True, blank=True)
    sender = GenericForeignKey('sender_content_type', 'sender_object_id')
    
    # Target audience - use these fields to specify who should receive the notification
    target_students = models.ManyToManyField('student', blank=True, related_name='notifications')
    target_trainers = models.ManyToManyField('Trainer', blank=True, related_name='notifications')
    target_schools = models.ManyToManyField('School', blank=True, related_name='notifications')
    
    # Class and school filters
    student_class = models.CharField(max_length=100, choices=CLASS_CHOICES, blank=True, null=True)
    school = models.ForeignKey('School', on_delete=models.CASCADE, null=True, blank=True)
    
    # Related object (optional - for linking to specific content)
    related_content_type = models.ForeignKey(
        ContentType, 
        on_delete=models.CASCADE, 
        null=True, 
        blank=True,
        related_name='notification_related'
    )
    related_object_id = models.PositiveIntegerField(null=True, blank=True)
    related_object = GenericForeignKey('related_content_type', 'related_object_id')
    
    # Notification settings
    is_active = models.BooleanField(default=True)
    requires_action = models.BooleanField(default=False)
    action_url = models.URLField(blank=True, null=True)
    action_text = models.CharField(max_length=100, blank=True, null=True)
    
    # Scheduling
    scheduled_for = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    
    # Tracking
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    sent_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['notification_type', 'is_active']),
            models.Index(fields=['scheduled_for', 'is_active']),
        ]
    
    def __str__(self):
        return f"{self.title} ({self.get_notification_type_display()})"
    
    @property
    def is_scheduled(self):
        return self.scheduled_for is not None and self.scheduled_for > timezone.now()
    
    @property
    def is_expired(self):
        return self.expires_at and self.expires_at < timezone.now()
    
    def can_send(self):
        """Check if notification can be sent"""
        if not self.is_active:
            return False
        if self.is_expired:
            return False
        if self.is_scheduled:
            return False
        return True
    
    def mark_sent(self):
        """Mark notification as sent"""
        if not self.sent_at:
            self.sent_at = timezone.now()
            self.save()
    
    def get_target_users(self):
        """Get all users who should receive this notification"""
        users = []
        
        # Add specific students
        users.extend([(ContentType.objects.get_for_model(student), s.id) for s in self.target_students.all()])
        
        # Add specific trainers
        users.extend([(ContentType.objects.get_for_model(Trainer), t.id) for t in self.target_trainers.all()])
        
        # Add users from target schools
        for school in self.target_schools.all():
            # Add students from the school
            school_students = student.objects.filter(school=school)
            users.extend([(ContentType.objects.get_for_model(student), s.id) for s in school_students])
            
            # Add trainers from the school
            school_trainers = Trainer.objects.filter(assigned_school=school)
            users.extend([(ContentType.objects.get_for_model(Trainer), t.id) for t in school_trainers])
        
        # Add users by class
        if self.student_class:
            class_students = student.objects.filter(student_class=self.student_class)
            users.extend([(ContentType.objects.get_for_model(student), s.id) for s in class_students])
        
        # Add users by school filter
        if self.school:
            school_students = student.objects.filter(school=self.school)
            users.extend([(ContentType.objects.get_for_model(student), s.id) for s in school_students])
            
            school_trainers = Trainer.objects.filter(assigned_school=self.school)
            users.extend([(ContentType.objects.get_for_model(Trainer), t.id) for t in school_trainers])
        
        # Remove duplicates
        users = list(set(users))
        
        return users

    # Add these properties for admin display
    @property
    def read_receipts_count(self):
        """Count of read receipts for this notification"""
        return self.receipts.filter(is_read=True).count()

    @property
    def delivered_receipts_count(self):
        """Count of delivered receipts for this notification"""
        return self.receipts.filter(delivered=True).count()

    @property
    def sender_display(self):
        """Display sender information"""
        if self.sender:
            return str(self.sender)
        return "System"

    @property
    def related_object_display(self):
        """Display related object information"""
        if self.related_object:
            return str(self.related_object)
        return "None"

    @property
    def total_recipients(self):
        """Total number of recipients for this notification"""
        return self.receipts.count()


class NotificationReceipt(models.Model):
    """
    Tracks which users have received/read the notification
    """
    notification = models.ForeignKey(Notification, on_delete=models.CASCADE, related_name='receipts')
    
    # Recipient information
    recipient_content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    recipient_object_id = models.PositiveIntegerField()
    recipient = GenericForeignKey('recipient_content_type', 'recipient_object_id')
    
    # Read status
    is_read = models.BooleanField(default=False)
    read_at = models.DateTimeField(null=True, blank=True)
    
    # Delivery status
    delivered = models.BooleanField(default=False)
    delivered_at = models.DateTimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['notification', 'recipient_content_type', 'recipient_object_id']
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Receipt for {self.notification.title} - {self.recipient}"
    
    def mark_read(self):
        """Mark notification as read"""
        if not self.is_read:
            self.is_read = True
            self.read_at = timezone.now()
            self.save()
    
    def mark_delivered(self):
        """Mark notification as delivered"""
        if not self.delivered:
            self.delivered = True
            self.delivered_at = timezone.now()
            self.save()


class NotificationPreference(models.Model):
    """
    User preferences for notifications
    """
    # User reference
    user_content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    user_object_id = models.PositiveIntegerField()
    user = GenericForeignKey('user_content_type', 'user_object_id')
    
    # Preference settings
    email_notifications = models.BooleanField(default=True)
    push_notifications = models.BooleanField(default=True)
    sms_notifications = models.BooleanField(default=False)
    
    # Type-specific preferences
    homework_notifications = models.BooleanField(default=True)
    exam_notifications = models.BooleanField(default=True)
    project_notifications = models.BooleanField(default=True)
    certificate_notifications = models.BooleanField(default=True)
    salary_notifications = models.BooleanField(default=True)
    attendance_notifications = models.BooleanField(default=True)
    counseling_notifications = models.BooleanField(default=True)
    resource_notifications = models.BooleanField(default=True)
    system_notifications = models.BooleanField(default=True)
    
    # Quiet hours
    quiet_hours_start = models.TimeField(null=True, blank=True)
    quiet_hours_end = models.TimeField(null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ['user_content_type', 'user_object_id']
    
    def __str__(self):
        return f"Preferences for {self.user}"
    
    @property
    def is_quiet_hours(self):
        """Check if current time is within quiet hours"""
        if not self.quiet_hours_start or not self.quiet_hours_end:
            return False
        
        now = timezone.now().time()
        return self.quiet_hours_start <= now <= self.quiet_hours_end

class CodingProject(models.Model):
    MODE_CHOICES = [
        ('block', 'Block Based'),
        ('text', 'Text Based'),
    ]

    student = models.ForeignKey(
        student,
        on_delete=models.CASCADE,
        related_name='coding_projects'
    )

    title = models.CharField(max_length=200)
    mode = models.CharField(max_length=10, choices=MODE_CHOICES)

    language = models.CharField(
        max_length=50,
        blank=True
    )

    board = models.CharField(
        max_length=50,
        blank=True
    )

    block_data = models.JSONField(blank=True, null=True)
    text_code = models.TextField(blank=True, null=True)

    sprite_data = models.JSONField(blank=True, null=True)
    backdrop = models.CharField(max_length=100, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)   # ✅ THIS WAS THE ISSUE

    def __str__(self):
        return f"{self.title} ({self.student.name})"