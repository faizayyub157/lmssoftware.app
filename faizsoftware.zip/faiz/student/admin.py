from django.contrib import admin
from django.db import models
from datetime import timedelta  
from .models import (
    student, Chapter, Exam, ObjectiveQuestion, ExamQuestion,
    StudentExamPerformance, StudentProgress, StudentProject, StudentExamResponse,
    Discussion, Comment, DiscussionLike, Homework, StudentRecentActivity, LiveClassRoom,
    VideoTutorial, Project, Commentproject, School, Trainer, Certificate, Module,
    UserAccess, Resource, HomeworkSubmission, DailyTaskUpdate, Salary,
    DocumentType, DocumentField, TrainerDocument, DocumentUploadProgress, UserProfile,
    CounselingSession, StudentCounselingRecord, Notification, NotificationReceipt,
    NotificationPreference, CodingProject
)
from django.db.models import Count, Avg, Q
from django.contrib.contenttypes.admin import GenericTabularInline
from django.contrib import messages
from django import forms
from django.utils.html import format_html
from django.urls import reverse, path
from django.core.exceptions import ValidationError
from django.shortcuts import render, redirect
from django.contrib.contenttypes.models import ContentType
from django.template.response import TemplateResponse
from django.utils import timezone

import json


# ---------------------------
# Student Admin
# ---------------------------
class StudentAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'enrollment', 'course', 'dob', 'enrollment_date', 'student_class', 'section', 'school']
    search_fields = ['name', 'email', 'school__name']
    list_filter = ['student_class', 'enrollment_date']
    actions = ['set_default_profile_image']

    def set_default_profile_image(self, request, queryset):
        for obj in queryset:
            obj.profile_image = 'profileimage/icon.png'  # this path should match the one set in ImageField
            obj.save()
        self.message_user(request, f"Set default profile image for {queryset.count()} students.")

    set_default_profile_image.short_description = "Set default profile image to icon.png for selected students"


class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = '__all__'

    def clean(self):
        cleaned_data = super().clean()
        student_obj = cleaned_data.get('student')
        trainer_obj = cleaned_data.get('trainer')

        if student_obj and trainer_obj:
            raise ValidationError("Profile can only be associated with either a student OR a trainer, not both.")

        if not student_obj and not trainer_obj:
            raise ValidationError("Profile must be associated with either a student or a trainer.")

        return cleaned_data


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    form = UserProfileForm
    list_display = ('get_user_name', 'get_user_type', 'phone', 'zip_code', 'updated_at')
    list_filter = ('student__school', 'trainer__assigned_school', 'updated_at')
    search_fields = (
        'student__name', 'trainer__name',
        'first_name', 'last_name', 'phone', 'zip_code'
    )
    readonly_fields = ('created_at', 'updated_at')
    fieldsets = (
        ('User Association', {
            'fields': (('student', 'trainer'),),
            'description': 'Select either a student or a trainer, but not both.'
        }),
        ('Personal Details', {
            'fields': (
                ('first_name', 'last_name'),
                'phone', 'zip_code', 'bio', 'cover_image'
            )
        }),
        ('Social Media', {
            'fields': (
                ('facebook_url', 'twitter_url'),
                ('linkedin_url', 'instagram_url')
            ),
            'classes': ('collapse',)
        }),
        ('Additional Contact', {
            'fields': (
                'secondary_phone', 'secondary_email', 'address'
            ),
            'classes': ('collapse',)
        }),
        ('Statistics', {
            'fields': (
                ('followers_count', 'following_count', 'likes_count')
            ),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def get_user_name(self, obj):
        return obj.get_user().name
    get_user_name.short_description = 'User Name'

    def get_user_type(self, obj):
        return obj.get_user_type()
    get_user_type.short_description = 'User Type'

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        # Add help text
        form.base_fields['student'].help_text = 'Select a student if this profile belongs to a student'
        form.base_fields['trainer'].help_text = 'Select a trainer if this profile belongs to a trainer'
        form.base_fields['cover_image'].help_text = 'Cover image shown at the top of the profile page'
        form.base_fields['bio'].help_text = 'User biography (supports plain text only)'
        return form


# ---------------------------
# Chapter Admin
# ---------------------------
class ChapterAdmin(admin.ModelAdmin):
    list_display = ('title', 'status', 'student_class')
    list_filter = ['student_class', 'status']


# ---------------------------
# Exam Admin
# ---------------------------
class ExamAdmin(admin.ModelAdmin):
    list_display = ('title', 'subject', 'total_marks', 'marks_per_question', 'exam_date', 'student_class', 'school')
    list_filter = ['student_class', 'school']
    search_fields = ['title', 'subject', 'school__name']


# ---------------------------
# ObjectiveQuestion Admin
# ---------------------------
class ObjectiveQuestionAdmin(admin.ModelAdmin):
    list_display = ('question_text', 'option1', 'option2', 'option3', 'option4', 'correct_answer')
    search_fields = ['question_text']


# ---------------------------
# ExamQuestion Admin
# ---------------------------
class ExamQuestionAdmin(admin.ModelAdmin):
    list_display = ('exam', 'question_text', 'correct_answer')
    search_fields = ['question_text']


# ---------------------------
# StudentExamPerformance Admin
# ---------------------------
class StudentExamPerformanceAdmin(admin.ModelAdmin):
    list_display = ('student', 'exam', 'marks_obtained', 'test_date')
    list_filter = ['student__student_class']
    search_fields = ['student__name', 'exam__title']


# ---------------------------
# StudentProgress Admin
# ---------------------------
class StudentProgressAdmin(admin.ModelAdmin):
    list_display = ('student', 'total_tests', 'avg_marks', 'last_exam_date')
    search_fields = ['student__name']


# ---------------------------
# StudentExamResponse Admin
# ---------------------------
class StudentExamResponseAdmin(admin.ModelAdmin):
    list_display = (
        'student_name',
        'exam_title',
        'question_text',
        'selected_answer',
        'correct_answer',
        'result_status',
        'created_at'
    )
    search_fields = (
        'student_exam_performance__student__name',
        'exam_question__question_text'
    )
    list_filter = ('result', 'selected_answer', 'exam_question__exam')
    readonly_fields = ('created_at',)
    date_hierarchy = 'created_at'

    fieldsets = (
        ('Student Info', {
            'fields': ('student_exam_performance',)
        }),
        ('Question Details', {
            'fields': ('exam_question', 'selected_answer', 'result')
        }),
        ('Timestamps', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )

    def student_name(self, obj):
        return obj.student_exam_performance.student.name
    student_name.short_description = 'Student'
    student_name.admin_order_field = 'student_exam_performance__student__name'

    def exam_title(self, obj):
        return obj.exam_question.exam.title
    exam_title.short_description = 'Exam'
    exam_title.admin_order_field = 'exam_question__exam__title'

    def question_text(self, obj):
        return obj.exam_question.question_text
    question_text.short_description = 'Question'
    question_text.admin_order_field = 'exam_question__question_text'

    def correct_answer(self, obj):
        return obj.exam_question.correct_answer
    correct_answer.short_description = 'Correct Answer'
    correct_answer.admin_order_field = 'exam_question__correct_answer'

    def result_status(self, obj):
        return obj.get_result_display()
    result_status.short_description = 'Result'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related(
            'student_exam_performance__student',
            'exam_question__exam'
        )


# ---------------------------
# Discussion Admin
# ---------------------------
@admin.register(Discussion)
class DiscussionAdmin(admin.ModelAdmin):
    list_display = ('student', 'truncated_content', 'created_at', 'likes_count', 'comments_count')
    search_fields = ('content', 'student__name')
    list_filter = ('created_at', 'student__student_class')

    def truncated_content(self, obj):
        return obj.content[:75]
    truncated_content.short_description = 'Content'

    def likes_count(self, obj):
        return obj.likes.count()
    likes_count.short_description = 'Likes'

    def comments_count(self, obj):
        return obj.comments.count()
    comments_count.short_description = 'Comments'


# ---------------------------
# Comment Admin
# ---------------------------
@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('student', 'truncated_content', 'discussion', 'created_at')
    search_fields = ('content', 'student__name')
    list_filter = ('created_at', 'student__student_class')

    def truncated_content(self, obj):
        return obj.content[:75]
    truncated_content.short_description = 'Content'


# ---------------------------
# DiscussionLike Admin
# ---------------------------
@admin.register(DiscussionLike)
class DiscussionLikeAdmin(admin.ModelAdmin):
    list_display = ('student', 'discussion', 'created_at')
    search_fields = ('student__name', 'discussion__content')
    list_filter = ('created_at', 'student__student_class')


# ---------------------------
# Homework Admin
# ---------------------------
class HomeworkAdmin(admin.ModelAdmin):
    list_display = (
        'student_class', 'chapter', 'school', 'trainer',
        'status', 'due_date', 'submitted_date', 'is_group_assignment'
    )
    list_filter = (
        'status', 'student_class', 'chapter__student_class', 'is_group_assignment',
        'school', 'trainer'
    )
    search_fields = (
        'chapter__title', 'student_class', 'school__name', 'trainer__name'
    )
    raw_id_fields = ('chapter', 'school', 'trainer',)
    date_hierarchy = 'due_date'


admin.site.register(Homework, HomeworkAdmin)


# ---------------------------
# StudentRecentActivity Admin
# ---------------------------
class StudentRecentActivityAdmin(admin.ModelAdmin):
    list_display = ('student', 'last_login', 'profile_updated_at')
    search_fields = ['student__name']
    list_filter = ('last_login', 'profile_updated_at')
    readonly_fields = ('last_login', 'profile_updated_at')


admin.site.register(StudentRecentActivity, StudentRecentActivityAdmin)


# ---------------------------
# LiveClassRoom Admin
# ---------------------------
class LiveClassroomAdmin(admin.ModelAdmin):
    list_display = ('room_id', 'host', 'created_at')
    search_fields = ('room_id', 'host__name')
    list_filter = ('created_at',)
    date_hierarchy = 'created_at'


admin.site.register(LiveClassRoom, LiveClassroomAdmin)


# ---------------------------
# VideoTutorial Admin
# ---------------------------
class VideoTutorialAdmin(admin.ModelAdmin):
    list_display = ('title', 'chapter', 'get_chapter_class', 'created_at')
    list_filter = ('chapter__student_class', 'created_at')
    search_fields = ('title', 'chapter__title', 'description')

    def get_chapter_class(self, obj):
        return obj.chapter.student_class
    get_chapter_class.short_description = 'Class'


admin.site.register(VideoTutorial, VideoTutorialAdmin)


# ---------------------------
# Project Admin
# ---------------------------
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'student', 'submitted_at', 'total_likes')
    search_fields = ('title', 'student__name')
    list_filter = ('submitted_at',)
    readonly_fields = ('submitted_at',)


# ---------------------------
# Commentproject Admin
# ---------------------------
class CommentprojectAdmin(admin.ModelAdmin):
    list_display = ('user', 'project', 'created_at')
    search_fields = ('user__username', 'project__title')
    list_filter = ('created_at',)


# ---------------------------
# School Admin
# ---------------------------
class SchoolAdmin(admin.ModelAdmin):
    list_display = ('name', 'appointed_trainer', 'payment_due', 'monthly_fee', 'address', 'contact_number')
    search_fields = ('name',)
    list_filter = ('monthly_fee',)


# ---------------------------
# Trainer Admin
# ---------------------------
class TrainerAdmin(admin.ModelAdmin):
    list_display = ('name', 'qualification', 'email', 'password', 'joining_date', 'salary', 'remaining_due', 'assigned_school', 'phone')
    search_fields = ('name', 'qualification', 'assigned_school__name')
    list_filter = ('joining_date', 'assigned_school')


class CertificateAdmin(admin.ModelAdmin):
    list_display = (
        'certificate_number',
        'get_student_name',
        'get_student_class',
        'get_school_name',
        'get_student_course',
        'achievement',
        'status',
        'request_date',
        'issued_date'
    )
    list_filter = ('status', 'achievement')
    search_fields = ('certificate_number', 'student__name', 'student__email')

    def get_student_name(self, obj):
        return obj.student.name
    get_student_name.short_description = 'Student Name'

    def get_student_class(self, obj):
        return obj.student.student_class
    get_student_class.short_description = 'Class'

    def get_school_name(self, obj):
        return obj.student.school.name if obj.student.school else ''
    get_school_name.short_description = 'School'

    def get_student_course(self, obj):
        return obj.student.course
    get_student_course.short_description = 'Course'


class ModuleAdmin(admin.ModelAdmin):
    list_display = ('name',)


class UserAccessAdmin(admin.ModelAdmin):
    list_display = ('role',)
    list_filter = ('role',)


class ResourceAdmin(admin.ModelAdmin):
    list_display = ('title', 'chapter', 'school', 'created_at')
    list_filter = ('chapter', 'school')
    search_fields = ('title', 'description')


@admin.register(HomeworkSubmission)
class HomeworkSubmissionAdmin(admin.ModelAdmin):
    list_display = ('student', 'homework', 'submitted_date', 'marks_obtained')
    list_filter = ('submitted_date', 'homework', 'marks_obtained')
    search_fields = ('student__name', 'homework__chapter__title')
    ordering = ('-submitted_date',)
    readonly_fields = ('submitted_date',)

    fieldsets = (
        ("Submission Details", {
            'fields': ('student', 'homework', 'submission_file', 'submitted_date')
        }),
        ("Evaluation", {
            'fields': ('marks_obtained', 'feedback')
        })
    )


# ---------------------------
# DailyTaskUpdate Admin
# ---------------------------
@admin.register(DailyTaskUpdate)
class DailyTaskUpdateAdmin(admin.ModelAdmin):
    list_display = ('trainer', 'date', 'status', 'submission_time', 'is_approved')
    list_filter = ('status', 'is_approved', 'date', 'trainer')
    search_fields = ('trainer__name', 'update_text')
    date_hierarchy = 'date'
    ordering = ('-date',)
    readonly_fields = ('submission_time',)

    actions = ['approve_as_present', 'approve_as_absent', 'approve_as_marked']

    def approve_as_present(self, request, queryset):
        updated_count = 0
        for update in queryset:
            if update.is_requested_update and not update.is_approved:
                update.status = 'present'
                update.is_approved = True
                update.save()
                updated_count += 1
        self.message_user(request, f"{updated_count} update(s) approved and marked as PRESENT.")
    approve_as_present.short_description = "Approve and mark as Present"

    def approve_as_absent(self, request, queryset):
        updated_count = 0
        for update in queryset:
            if update.is_requested_update and not update.is_approved:
                update.status = 'absent'
                update.is_approved = True
                update.save()
                updated_count += 1
        self.message_user(request, f"{updated_count} update(s) approved and marked as ABSENT.")
    approve_as_absent.short_description = "Approve and mark as Absent"

    def approve_as_marked(self, request, queryset):
        updated_count = 0
        for update in queryset:
            if update.is_requested_update and not update.is_approved:
                update.is_approved = True
                update.save()
                updated_count += 1
        self.message_user(request, f"{updated_count} requested update(s) approved with trainer's marked status.")
    approve_as_marked.short_description = "Approve as marked (keep existing status)"

    fieldsets = (
        ('Basic Information', {
            'fields': ('trainer', 'date', 'status')
        }),
        ('Update Details', {
            'fields': ('update_text', 'update_image')
        }),
        ('Status Information', {
            'fields': ('is_requested_update', 'is_approved', 'submission_time')
        }),
    )


# ---------------------------
# Salary Admin
# ---------------------------
@admin.register(Salary)
class SalaryAdmin(admin.ModelAdmin):
    list_display = ('trainer', 'month', 'present_days', 'prorated_basic', 'hra', 'allowances', 'tax', 'pf', 'net_salary', 'status')
    list_filter = ('status', 'month')
    search_fields = ('trainer__name',)

    fieldsets = (
        ('Trainer Info', {
            'fields': ('trainer', 'month', 'status', 'payment_date')
        }),
        ('Attendance & Base Salary', {
            'fields': ('present_days', 'basic', 'prorated_basic')
        }),
        ('Manual Salary Components', {
            'fields': ('hra', 'allowances', 'tax', 'pf', 'other_deductions')
        }),
        ('Final Calculation', {
            'fields': ('net_salary',)
        }),
    )

    actions = ['refresh_attendance_and_salary']

    @admin.action(description="Refresh attendance and recalculate salary")
    def refresh_attendance_and_salary(self, request, queryset):
        updated_count = 0
        for salary in queryset:
            salary.refresh_attendance_and_recalculate()
            salary.save()
            updated_count += 1
        self.message_user(request, f"Successfully refreshed salary for {updated_count} record(s).", messages.SUCCESS)


# ---------------------------
# DocumentType / TrainerDocument / UploadProgress Admin
# ---------------------------
class DocumentFieldInline(admin.TabularInline):
    model = DocumentField
    extra = 1
    fields = ('name', 'label', 'field_type', 'is_required', 'pattern', 'min_value', 'max_value', 'options')


@admin.register(DocumentType)
class DocumentTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'is_required', 'fields_count')
    list_filter = ('category', 'is_required')
    search_fields = ('name', 'description')
    inlines = [DocumentFieldInline]

    def fields_count(self, obj):
        return obj.fields.count()
    fields_count.short_description = 'Fields'


@admin.register(TrainerDocument)
class TrainerDocumentAdmin(admin.ModelAdmin):
    list_display = ('trainer', 'document_type', 'status', 'submitted_at', 'verified_at', 'file_link')
    list_filter = ('status', 'document_type', 'submitted_at')
    search_fields = ('trainer__name', 'document_type__name')
    readonly_fields = ('submitted_at', 'verified_at', 'file_preview')

    def file_link(self, obj):
        if obj.document_file:
            return format_html('<a href="{}" target="_blank">View File</a>', obj.document_file.url)
        return "-"
    file_link.short_description = 'File'

    def file_preview(self, obj):
        if obj.document_file:
            if obj.document_file.name.lower().endswith(('.jpg', '.jpeg', '.png')):
                return format_html('<img src="{}" style="max-height: 200px; max-width: 100%;"/>', obj.document_file.url)
            return format_html('<a href="{}" target="_blank">Download File</a>', obj.document_file.url)
        return "-"
    file_preview.short_description = 'Preview'


@admin.register(DocumentUploadProgress)
class DocumentUploadProgressAdmin(admin.ModelAdmin):
    list_display = ('trainer', 'progress_display', 'last_updated')
    readonly_fields = ('required_documents_count', 'completed_documents_count', 'completion_percentage', 'last_updated')
    search_fields = ('trainer__name',)

    def progress_display(self, obj):
        return obj.get_progress_display()
    progress_display.short_description = 'Progress'


# ---------------------------
# CounselingSession + StudentCounselingRecord Admin
# ---------------------------
class StudentCounselingRecordInline(admin.TabularInline):
    model = StudentCounselingRecord
    extra = 0
    fields = ['student', 'interested_in_robotics', 'interest_level', 'favorite_subject']
    readonly_fields = ['student']
    can_delete = False

    def has_add_permission(self, request, obj):
        return False

    def has_change_permission(self, request, obj=None):
        return obj and not obj.is_locked()


@admin.register(CounselingSession)
class CounselingSessionAdmin(admin.ModelAdmin):
    list_display = [
        'date_of_session',
        'school',
        'student_class',
        'section',
        'counselor',
        'get_students_count',
        'status',
        'locked_at'
    ]

    list_filter = [
        'date_of_session',
        'school',
        'student_class',
        'section',
        'counselor',
        'status'
    ]

    search_fields = [
        'school__name',
        'counselor__name',
        'session_notes'
    ]

    readonly_fields = [
        'created_at',
        'updated_at',
        'locked_at',
        'status'
    ]

    fieldsets = (
        ('Session Information', {
            'fields': (
                'counselor',
                'school',
                'date_of_session',
                'student_class',
                'section',
                'status',
            )
        }),
        ('Session Notes', {
            'fields': ('session_notes',)
        }),
        ('System Information', {
            'fields': ('created_at', 'updated_at', 'locked_at'),
            'classes': ('collapse',)
        }),
    )

    inlines = [StudentCounselingRecordInline]

    actions = ['lock_sessions', 'unlock_sessions']

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path(
                '<path:object_id>/start-counseling/',
                self.admin_site.admin_view(self.start_counseling_view),
                name='student_counselingsession_start_counseling',
            ),
        ]
        return custom_urls + urls

    def start_counseling_view(self, request, object_id):
        session = CounselingSession.objects.get(id=object_id)

        if request.method == 'POST':
            selected_students = request.POST.getlist('students')
            for student_id in selected_students:
                student_obj = student.objects.get(id=student_id)
                StudentCounselingRecord.objects.get_or_create(
                    counseling_session=session,
                    student=student_obj
                )

            session.status = 'in_progress'
            session.save()

            messages.success(request, f'Added {len(selected_students)} students to counseling session')
            return redirect(f'../{object_id}/change/')

        students_qs = student.objects.filter(
            student_class=session.student_class,
            section=session.section,
            school=session.school
        ).exclude(
            counseling_records__counseling_session=session
        )

        context = {
            **self.admin_site.each_context(request),
            'session': session,
            'students': students_qs,
            'title': 'Add Students to Counseling Session'
        }
        return render(request, 'admin/student/counseling_start.html', context)

    def lock_sessions(self, request, queryset):
        for sess in queryset:
            if sess.status != 'locked':
                sess.lock_session()
        self.message_user(request, f"{queryset.count()} sessions locked successfully.")
    lock_sessions.short_description = "Lock selected counseling sessions"

    def unlock_sessions(self, request, queryset):
        for sess in queryset:
            if sess.status == 'locked':
                sess.unlock_session()
        self.message_user(request, f"{queryset.count()} sessions unlocked.")
    unlock_sessions.short_description = "Unlock selected counseling sessions"

    def get_students_count(self, obj):
        return obj.get_students_count()
    get_students_count.short_description = 'Students'

    def save_model(self, request, obj, form, change):
        if not change:
            if hasattr(request.user, 'trainer'):
                obj.counselor = request.user.trainer
        super().save_model(request, obj, form, change)


@admin.register(StudentCounselingRecord)
class StudentCounselingRecordAdmin(admin.ModelAdmin):
    list_display = [
        'student',
        'counseling_session',
        'interested_in_robotics',
        'interest_level',
        'favorite_subject',
        'parent_involvement'
    ]

    list_filter = [
        'counseling_session__school',
        'counseling_session__date_of_session',
        'interested_in_robotics',
        'interest_level',
        'parent_involvement'
    ]

    search_fields = [
        'student__name',
        'favorite_subject',
        'career_aspiration'
    ]

    fieldsets = (
        ('Session Information', {
            'fields': ('counseling_session', 'student')
        }),
        ('Student Interests', {
            'fields': (
                'interested_in_robotics',
                'interest_level',
                'favorite_subject',
                'career_aspiration'
            )
        }),
        ('Feedback', {
            'fields': (
                'parent_involvement',
                'parent_feedback',
                'student_feedback',
                'counselor_notes'
            )
        }),
        ('Contact Information', {
            'fields': ('contact_number',)
        }),
    )

    def get_readonly_fields(self, request, obj=None):
        if obj and obj.counseling_session.is_locked():
            return [field.name for field in self.model._meta.fields]
        return ['counseling_session', 'student']

    def has_change_permission(self, request, obj=None):
        if obj and obj.counseling_session.is_locked():
            return False
        return super().has_change_permission(request, obj)

    def has_delete_permission(self, request, obj=None):
        if obj and obj.counseling_session.is_locked():
            return False
        return super().has_delete_permission(request, obj)


# ---------------------------
# Notification Admin
# ---------------------------
@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = [
        'title',
        'notification_type',
        'priority',
        'sender_display',
        'is_active',
        'created_at',
        'read_receipts_count',
        'delivered_receipts_count'
    ]

    list_filter = [
        'notification_type',
        'priority',
        'is_active',
        'created_at'
    ]

    search_fields = ['title', 'message']

    readonly_fields = [
        'created_at',
        'updated_at',
        'sent_at',
        'read_receipts_count',
        'delivered_receipts_count',
        'sender_display',
        'related_object_display'
    ]

    fieldsets = (
        ('Notification Content', {
            'fields': (
                'title',
                'message',
                'notification_type',
                'priority'
            )
        }),
        ('Sender Information', {
            'fields': (
                'sender_content_type',
                'sender_object_id',
                'sender_display'
            ),
            'classes': ('collapse',)
        }),
        ('Target Audience', {
            'fields': (
                'target_students',
                'target_trainers',
                'target_schools',
                'student_class',
                'school'
            )
        }),
        ('Related Object', {
            'fields': (
                'related_content_type',
                'related_object_id',
                'related_object_display'
            ),
            'classes': ('collapse',)
        }),
        ('Notification Settings', {
            'fields': (
                'is_active',
                'requires_action',
                'action_url',
                'action_text'
            )
        }),
        ('Scheduling', {
            'fields': (
                'scheduled_for',
                'expires_at'
            )
        }),
        ('Tracking', {
            'fields': (
                'created_at',
                'updated_at',
                'sent_at',
                'read_receipts_count',
                'delivered_receipts_count'
            )
        })
    )

    def get_queryset(self, request):
        return super().get_queryset(request).prefetch_related('receipts')


class NotificationReceiptInline(admin.TabularInline):
    model = NotificationReceipt
    extra = 0
    readonly_fields = ['recipient', 'created_at', 'updated_at']
    can_delete = False

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(NotificationReceipt)
class NotificationReceiptAdmin(admin.ModelAdmin):
    list_display = [
        'notification',
        'recipient',
        'is_read',
        'delivered',
        'created_at'
    ]

    list_filter = ['is_read', 'delivered', 'created_at']
    search_fields = ['notification__title']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(NotificationPreference)
class NotificationPreferenceAdmin(admin.ModelAdmin):
    list_display = [
        'user',
        'email_notifications',
        'push_notifications',
        'sms_notifications'
    ]

    list_filter = [
        'email_notifications',
        'push_notifications',
        'sms_notifications'
    ]

    readonly_fields = ['created_at', 'updated_at']

    fieldsets = (
        ('User', {
            'fields': (
                'user_content_type',
                'user_object_id',
            )
        }),
        ('Notification Channels', {
            'fields': (
                'email_notifications',
                'push_notifications',
                'sms_notifications',
            )
        }),
        ('Notification Types', {
            'fields': (
                'homework_notifications',
                'exam_notifications',
                'project_notifications',
                'certificate_notifications',
                'salary_notifications',
                'attendance_notifications',
                'counseling_notifications',
                'resource_notifications',
                'system_notifications',
            )
        }),
        ('Quiet Hours', {
            'fields': (
                'quiet_hours_start',
                'quiet_hours_end',
            ),
            'classes': ('collapse',)
        }),
        ('Timestamps', {
            'fields': (
                'created_at',
                'updated_at',
            ),
            'classes': ('collapse',)
        })
    )


# ---------------------------
# Register remaining models
# ---------------------------
admin.site.register(student, StudentAdmin)
admin.site.register(Chapter, ChapterAdmin)
admin.site.register(Exam, ExamAdmin)
admin.site.register(ObjectiveQuestion, ObjectiveQuestionAdmin)
admin.site.register(ExamQuestion, ExamQuestionAdmin)
admin.site.register(StudentExamPerformance, StudentExamPerformanceAdmin)
admin.site.register(StudentProgress, StudentProgressAdmin)
admin.site.register(StudentExamResponse, StudentExamResponseAdmin)
admin.site.register(Project, ProjectAdmin)
admin.site.register(Commentproject, CommentprojectAdmin)
admin.site.register(School, SchoolAdmin)
admin.site.register(Trainer, TrainerAdmin)
admin.site.register(Certificate, CertificateAdmin)
admin.site.register(Module, ModuleAdmin)
admin.site.register(UserAccess, UserAccessAdmin)
admin.site.register(Resource, ResourceAdmin)
admin.site.register(DocumentField)


# ======================================================================
# 🔥 CUSTOM ADMIN DASHBOARD (GRAPHICAL) - /admin/dashboard/
# ======================================================================
def admin_dashboard_view(request):
    """
    Custom graphical dashboard for Django admin.
    URL: /admin/dashboard/
    """
    # Summary counts
    total_students = student.objects.count()
    total_schools = School.objects.count()
    total_trainers = Trainer.objects.count()
    total_exams = Exam.objects.count()
    total_homeworks = Homework.objects.count()

    # Students by class
    students_by_class_qs = (
        student.objects.values('student_class')
        .annotate(total=Count('id'))
        .order_by('student_class')
    )
    students_class_labels = [row['student_class'] for row in students_by_class_qs]
    students_class_data = [row['total'] for row in students_by_class_qs]

    # 🔧 FIXED: Students by school – use 'students' instead of 'student'
    students_by_school_qs = (
        School.objects.annotate(total=Count('students'))   # <-- here
        .values('name', 'total')
        .order_by('name')
    )
    students_school_labels = [row['name'] for row in students_by_school_qs]
    students_school_data = [row['total'] for row in students_by_school_qs]

    # Homework status distribution
    homework_status_qs = Homework.objects.values('status').annotate(total=Count('id'))
    homework_status_labels = [row['status'] for row in homework_status_qs]
    homework_status_data = [row['total'] for row in homework_status_qs]

    # Exams by class
    exams_by_class_qs = (
        Exam.objects.values('student_class')
        .annotate(total=Count('id'))
        .order_by('student_class')
    )
    exams_class_labels = [row['student_class'] for row in exams_by_class_qs]
    exams_class_data = [row['total'] for row in exams_by_class_qs]

    # Daily task update status
    task_status_qs = DailyTaskUpdate.objects.values('status').annotate(total=Count('id'))
    task_status_labels = [row['status'] for row in task_status_qs]
    task_status_data = [row['total'] for row in task_status_qs]

    # Average exam marks
    exam_stats = StudentExamPerformance.objects.aggregate(
        avg_marks=Avg('marks_obtained'),
        total_attempts=Count('id')
    )

    from django.template.response import TemplateResponse  # if not already imported at top

    context = dict(
        admin.site.each_context(request),
        title="Admin Dashboard",
        total_students=total_students,
        total_schools=total_schools,
        total_trainers=total_trainers,
        total_exams=total_exams,
        total_homeworks=total_homeworks,
        exam_stats=exam_stats,

        students_class_labels=json.dumps(students_class_labels),
        students_class_data=json.dumps(students_class_data),

        students_school_labels=json.dumps(students_school_labels),
        students_school_data=json.dumps(students_school_data),

        homework_status_labels=json.dumps(homework_status_labels),
        homework_status_data=json.dumps(homework_status_data),

        exams_class_labels=json.dumps(exams_class_labels),
        exams_class_data=json.dumps(exams_class_data),

        task_status_labels=json.dumps(task_status_labels),
        task_status_data=json.dumps(task_status_data),
    )

    return TemplateResponse(request, "admin/dashboard.html", context)


# Inject dashboard URL into default admin.site
def get_admin_urls(original_get_urls):
    def wrapper():
        urls = original_get_urls()
        custom_urls = [
            path("dashboard/", admin.site.admin_view(admin_dashboard_view), name="admin_dashboard"),
        ]
        return custom_urls + urls
    return wrapper


admin.site.get_urls = get_admin_urls(admin.site.get_urls)


@admin.register(CodingProject)
class CodingProjectAdmin(admin.ModelAdmin):
    list_display = (
        'title',
        'student',
        'mode',
        'language',
        'board',
        'updated_at'
    )

    list_filter = ('mode', 'language', 'board')
    search_fields = ('title', 'student__name')
    readonly_fields = ('created_at', 'updated_at')