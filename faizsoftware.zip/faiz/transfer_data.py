# transfer_data.py
import sqlite3
import json

def transfer_data(old_db_path, new_db_path):
    # Connect to both databases
    old_conn = sqlite3.connect(old_db_path)
    new_conn = sqlite3.connect(new_db_path)
    
    old_cursor = old_conn.cursor()
    new_cursor = new_conn.cursor()
    
    # Get list of tables from old database
    old_cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = old_cursor.fetchall()
    
    for table in tables:
        table_name = table[0]
        
        # Skip sqlite_sequence and django_migrations
        if table_name in ['sqlite_sequence', 'django_migrations']:
            continue
            
        print(f"Transferring data from {table_name}...")
        
        # Get table structure from old database
        old_cursor.execute(f"PRAGMA table_info({table_name})")
        columns = old_cursor.fetchall()
        column_names = [col[1] for col in columns]
        
        # Get all data from old table
        old_cursor.execute(f"SELECT * FROM {table_name}")
        rows = old_cursor.fetchall()
        
        # Prepare insert statement
        placeholders = ', '.join(['?'] * len(column_names))
        insert_sql = f"INSERT OR REPLACE INTO {table_name} ({', '.join(column_names)}) VALUES ({placeholders})"
        
        # Insert data into new table
        for row in rows:
            try:
                new_cursor.execute(insert_sql, row)
            except Exception as e:
                print(f"Error inserting into {table_name}: {e}")
                # Try without the id column if it's auto-increment
                if "UNIQUE constraint failed" in str(e):
                    # Remove id from columns and values
                    if 'id' in column_names:
                        idx = column_names.index('id')
                        new_columns = column_names[:idx] + column_names[idx+1:]
                        new_values = row[:idx] + row[idx+1:]
                        insert_sql2 = f"INSERT INTO {table_name} ({', '.join(new_columns)}) VALUES ({', '.join(['?']*len(new_columns))})"
                        new_cursor.execute(insert_sql2, new_values)
        
        new_conn.commit()
        print(f"Transferred {len(rows)} rows from {table_name}")
    
    old_conn.close()
    new_conn.close()
    print("Data transfer completed!")

# Usage
transfer_data('C:\Users\faiza\OneDrive\Documents\Desktop\faiz\template\db.sqlite3', 'C:\Users\faiza\OneDrive\Documents\Desktop\faiz\db.sqlite3')