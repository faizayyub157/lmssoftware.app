from django import template

register = template.Library()

@register.simple_tag
def build_query_string(**kwargs):
    from django.http import QueryDict
    from django.utils.http import urlencode
    
    query_dict = QueryDict(mutable=True)
    
    # Add existing parameters from request
    for key, value in kwargs.get('request', {}).items():
        if key != 'page':  # Don't include existing page parameter
            query_dict[key] = value
    
    # Add new parameters
    for key, value in kwargs.items():
        if key != 'request' and value is not None:
            query_dict[key] = value
    
    return query_dict.urlencode()