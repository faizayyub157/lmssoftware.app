from django import template
from faiz import UserModule

register = template.Library()

@register.simple_tag
def get_available_modules(user):
    """Fetch available modules based on the user's role."""
    return UserModule.objects.filter(role=user.role).values_list('module_name', flat=True)
