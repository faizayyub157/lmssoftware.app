from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponse
import json
import time
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.hashers import check_password, make_password
from django.utils import timezone
from datetime import timedelta, datetime, date
from django.db.models import Avg, F, FloatField, Sum, Count
from django.core.cache import cache
import uuid
from django.db import transaction
import openpyxl
from django.core.files.storage import default_storage
import calendar
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.contrib import messages
from django.contrib.contenttypes.models import ContentType
from django.db.models import F, ExpressionWrapper, FloatField
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import get_object_or_404
from datetime import date
import csv
import asyncio
import websockets
from threading import Thread
import queue
import tempfile
import subprocess
import os
from decimal import Decimal
from django.utils.dateparse import parse_date
import serial
import serial.tools.list_ports

# Import models and forms
from .forms import LoginForm, ExamForm, ExamQuestionFormSet, ObjectiveQuestionForm, StudentProjectForm, CertificateRequestForm, DocumentUploadForm  # This should now work
from student.models import (
    student,  # custom student model
    Chapter,
    DocumentType,
    Exam,
    ObjectiveQuestion,
    ExamQuestion,
    UserProfile,
    StudentExamPerformance,
    StudentExamResponse,
    Discussion,
    TrainerDocument, 
    DocumentUploadProgress,
    Comment, 
    DiscussionLike, 
    Homework, 
    StudentRecentActivity, 
    LiveClassRoom, 
    VideoTutorial, 
    Project,
    Certificate,
    Trainer,
    School,
    Resource,
    DailyTaskUpdate,
    Salary,
    UserAccess,
    CounselingSession,
    StudentCounselingRecord,
    Notification, NotificationReceipt, NotificationPreference, CodingProject,
    CLASS_CHOICES
    )
from django.views.decorators.http import require_POST
from django.http import HttpResponseForbidden
from django.db.models import Q  # Add this import
# ============================================================================
# Helper Functions and Custom Decorators
# ============================================================================

def get_logged_in_user(request):
    user_id = request.session.get('user_id')
    user_type = request.session.get('user_type')
    
    if not user_id or not user_type:
        return None
    
    try:
        if user_type == 'student':
            return student.objects.get(id=user_id)
        else:
            return Trainer.objects.get(id=user_id)
    except (student.DoesNotExist, Trainer.DoesNotExist):
        return None

def login_required(view_func):
    def wrapper(request, *args, **kwargs):
        user = get_logged_in_user(request)
        if not user:
            return redirect('login')
        
        # Check if the view expects a 'user' parameter
        import inspect
        sig = inspect.signature(view_func)
        if 'user' in sig.parameters:
            return view_func(request, user, *args, **kwargs)
        else:
            return view_func(request, *args, **kwargs)
    return wrapper

def _get_logged_trainer(user):
    """
    Helper: try to return Trainer instance associated with request.user.
    Adjust if your Trainer relation is different (eg. Trainer extends AbstractUser).
    """
    # common pattern: User has OneToOneField -> trainer
    trainer = getattr(user, 'trainer', None)
    # if your Trainer _is_ the User model, you might do:
    # if isinstance(user, Trainer): trainer = user
    return trainer

# ============================================================================
# Views
# ============================================================================

@csrf_exempt  # Temporarily disable CSRF for testing (use proper CSRF handling in production)
def change_password(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            current_password = data.get('currentPassword')
            new_password = data.get('newPassword')
            confirm_new_password = data.get('confirmNewPassword')

            user_id = request.session.get('user_id')
            if not user_id:
                return JsonResponse({'success': False, 'error': 'User not authenticated'}, status=401)

            try:
                user = student.objects.get(id=user_id)
            except student.DoesNotExist:
                return JsonResponse({'success': False, 'error': 'User not found'}, status=404)

            # Check if the current password is correct
            if not check_password(current_password, user.password):
                return JsonResponse({'success': False, 'error': 'Current password is incorrect'}, status=400)

            # Validate new password and confirmation
            if new_password != confirm_new_password:
                return JsonResponse({'success': False, 'error': 'New passwords do not match'}, status=400)

            # Update the password
            user.password = make_password(new_password)
            user.save()

            return JsonResponse({'success': True, 'message': 'Password updated successfully'})

        except json.JSONDecodeError:
            return JsonResponse({'success': False, 'error': 'Invalid JSON data'}, status=400)
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=500)

    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)

@login_required
def add_exam(request, user):
    # Check if user is a trainer
    if not isinstance(user, Trainer):
        return render(request, 'add_exam.html', {
            'error_message': "Only trainers are allowed to add exams."
        })

    school = user.assigned_school  # Take school from trainer automatically

    if request.method == 'POST':
        # Retrieve exam details from the POST data
        exam_name = request.POST.get('exam_name')
        subject = request.POST.get('subject')
        exam_class = request.POST.get('exam_class')  # Example: "4" → will store as "Class 4"
        total_marks = request.POST.get('total_marks')
        marks_per_question = request.POST.get('marks_per_question')
        exam_date = request.POST.get('exam_date')

        # Format class name properly (e.g., Class 4, Class 5)
        if exam_class and not exam_class.lower().startswith("class"):
            exam_class = f"Class {exam_class.strip()}"

        # Validate and parse the exam date
        if exam_date:
            try:
                exam_date = timezone.datetime.strptime(exam_date, "%Y-%m-%d").date()
            except ValueError:
                return render(request, 'add_exam.html', {
                    'error_message': "Invalid date format. Please use YYYY-MM-DD.",
                    'user': user
                })
        else:
            exam_date = timezone.now().date()

        # Create the Exam instance
        try:
            exam = Exam.objects.create(
                title=exam_name,
                subject=subject,
                total_marks=int(total_marks),
                marks_per_question=int(marks_per_question),
                exam_date=exam_date,
                student_class=exam_class,
                school=school  # Auto assign school of trainer
            )
        except ValueError:
            return render(request, 'add_exam.html', {
                'error_message': "Please provide valid numeric values for total marks and marks per question.",
                'user': user
            })

        # Loop through the submitted questions and add them
        question_count = 0
        while True:
            question_text = request.POST.get(f'question_text_{question_count + 1}')
            if not question_text:
                break  # Stop when there are no more questions

            option_a = request.POST.get(f'option_a_{question_count + 1}')
            option_b = request.POST.get(f'option_b_{question_count + 1}')
            option_c = request.POST.get(f'option_c_{question_count + 1}')
            option_d = request.POST.get(f'option_d_{question_count + 1}')
            correct_answer = request.POST.get(f'correct_answer_{question_count + 1}')

            if all([question_text, option_a, option_b, option_c, option_d, correct_answer]):
                ExamQuestion.objects.create(
                    exam=exam,
                    question_text=question_text,
                    option_a=option_a,
                    option_b=option_b,
                    option_c=option_c,
                    option_d=option_d,
                    correct_answer=correct_answer
                )
            else:
                return render(request, 'add_exam.html', {
                    'error_message': f"All fields are required for Question {question_count + 1}.",
                    'user': user
                })

            question_count += 1

        return redirect('exam')  # Redirect to exam list page after saving

    # For GET requests, render the add exam form
    return render(request, 'add_exam.html', {
        'user': user,
        'school': school,
    })

def display_exams(request):
    # This view appears to be for displaying objective questions.
    questions = ObjectiveQuestion.objects.all()  # Fetch all questions from the database
    return render(request, 'display_exams.html', {'questions': questions})
    

def login_view(request):
    if request.session.get('user_id') and request.session.get('user_type'):
        return redirect('dashboard')
    
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user_type = form.cleaned_data['user_type']

            # Get appropriate model
            if user_type == 'student':
                user_model = student
            else:
                user_model = Trainer

            try:
                user = user_model.objects.get(email=email)
                # Use proper password check
                if user.check_password(password):
                    request.session['user_id'] = user.id
                    request.session['user_type'] = user_type
                    
                    # Update activity for students
                    if user_type == 'student':
                        recent_activity, created = StudentRecentActivity.objects.get_or_create(student=user)
                        recent_activity.update_last_login()
                    
                    return redirect('dashboard' if user_type == 'student' else 'dashboard')
                else:
                    form.add_error(None, 'Invalid password')
            except user_model.DoesNotExist:
                form.add_error(None, 'User not found')
        return render(request, 'login.html', {'form': form})
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    request.session.flush()  # Clears the session
    return redirect('login')


# ============================================================================
# Main Student Views (All decorated with our custom login_required)
# ============================================================================

@login_required
def home(request, user):
    """Home page with student data, relevant chapters, upcoming homework deadlines, school name, and appointed trainer."""
    # Query chapters for the student's class
    chapters = Chapter.objects.filter(student_class=user.student_class)
    
    # (Optional) Query all students if needed
    studentdata = student.objects.all()
    
    # Query upcoming homework for the student's class and school
    upcoming_homework = Homework.objects.filter(
        student_class=user.student_class,
        school=user.school,
        due_date__gte=timezone.now()
    ).order_by('due_date')
    
    # Fetch school name and appointed trainer from the student's school, if available
    school_name = user.school.name if user.school else None
    trainer = user.school.appointed_trainer if user.school else None
    
    data = {
        'user': user,
        'studentdata': studentdata,
        'chapters': chapters,
        'upcoming_homework': upcoming_homework,
        'school_name': school_name,
        'trainer': trainer,
    }
    return render(request, 'dashboard.html', data)



@login_required
def dashboard(request, user):
    now_time = timezone.now()
    is_trainer = isinstance(user, Trainer)
    context = {'user': user, 'is_trainer': is_trainer}

    if is_trainer:
        school = user.assigned_school
        students = student.objects.filter(school=school)
        exams = Exam.objects.filter(school=school)
        homework_assignments = Homework.objects.filter(school=school)
        
        # Get recent student activities
        recent_activities = StudentRecentActivity.objects.filter(
            student__school=school
        ).select_related('student').order_by('-last_login')[:10]

        # ---- CLASS PERFORMANCE LOGIC ----
        class_labels = []
        class_avg_scores = []

        # Group students by class
        classes = students.values_list('student_class', flat=True).distinct()
        for cls in classes:
            class_students = students.filter(student_class=cls)
            performances = StudentExamPerformance.objects.filter(student__in=class_students)

            total_marks = 0
            total_possible = 0
            for perf in performances:
                if perf.exam.total_marks > 0:
                    total_marks += perf.marks_obtained
                    total_possible += perf.exam.total_marks

            avg_percentage = (total_marks / total_possible * 100) if total_possible > 0 else 0

            class_labels.append(str(cls))  # or cls.name if class is model
            class_avg_scores.append(round(avg_percentage, 2))

        # Prepare JSON for Chart.js
        context.update({
            'class_chart_labels': json.dumps(class_labels),
            'class_chart_data': json.dumps(class_avg_scores),
        })

        # ---- Existing trainer data ----
        upcoming_classes = LiveClassRoom.objects.filter(
            participants__school=school
        ).distinct().count()

        current_assignments = homework_assignments.filter(
            due_date__gte=now_time,
            due_date__lte=now_time + timedelta(days=7)
        )
        upcoming_assignments = homework_assignments.filter(
            due_date__gt=now_time + timedelta(days=7)
        )
        past_assignments = homework_assignments.filter(
            due_date__lt=now_time
        ).order_by('-due_date')

        context.update({
            'total_students': students.count(),
            'total_exams': exams.count(),
            'upcoming_classes': upcoming_classes,
            'school': school,
            'students': students[:5],
            'recent_exams': exams.order_by('-exam_date')[:3],
            'current_assignments': current_assignments,
            'upcoming_assignments': upcoming_assignments,
            'past_assignments': past_assignments,
            'recent_activities': recent_activities,  # Add recent activities to context
        })
    else:
        # Student dashboard logic
        student_class = user.student_class
        school = user.school
        performances = StudentExamPerformance.objects.filter(student=user).order_by('test_date')

        chart_labels = []
        chart_data = []
        total_obtained = 0
        total_possible = 0

        for perf in performances:
            percentage = (perf.marks_obtained / perf.exam.total_marks * 100) if perf.exam.total_marks > 0 else 0
            chart_labels.append(perf.test_date.strftime("%Y-%m-%d"))
            chart_data.append(round(percentage, 2))
            total_obtained += perf.marks_obtained
            total_possible += perf.exam.total_marks

        # Get all assignment types for student
        current_assignments = Homework.objects.filter(
            student_class=student_class,
            school=school,
            due_date__gte=now_time,
            due_date__lte=now_time + timedelta(days=7)
        ).order_by('due_date')

        upcoming_assignments = Homework.objects.filter(
            student_class=student_class,
            school=school,
            due_date__gt=now_time + timedelta(days=7)
        ).order_by('due_date')

        past_assignments = Homework.objects.filter(
            student_class=student_class,
            school=school,
            due_date__lt=now_time
        ).order_by('-due_date')

        context.update({
            'chapters': Chapter.objects.filter(student_class=student_class),
            'chart_labels': json.dumps(chart_labels),
            'chart_data': json.dumps(chart_data),
            'overall_progress': (total_obtained / total_possible * 100) if total_possible > 0 else 0,
            'current_assignments': current_assignments,
            'upcoming_assignments': upcoming_assignments,
            'past_assignments': past_assignments,
            'last_login': user.recent_activity.last_login if hasattr(user, 'recent_activity') else None,
            'completed_assignments': past_assignments.count(),
            'pending_assignments': current_assignments.count() + upcoming_assignments.count(),
            'total_assignments': Homework.objects.filter(
                student_class=student_class,
                school=school
            ).count()
        })

    return render(request, 'dashboard.html', context)
@login_required
def update_trainer_profile(request):
    if request.method == 'POST':
        try:
            user = request.user
            
            # Update basic info
            if 'name' in request.POST:
                user.name = request.POST.get('name', user.name)
            
            if 'email' in request.POST:
                user.email = request.POST.get('email', user.email)
            
            if 'phone' in request.POST:
                user.phone = request.POST.get('phone', user.phone)
            
            if 'gender' in request.POST:
                user.gender = request.POST.get('gender', user.gender)
            
            if 'qualification' in request.POST:
                user.qualification = request.POST.get('qualification', user.qualification)
            
            if 'experience_years' in request.POST:
                try:
                    user.experience_years = int(request.POST.get('experience_years', 0))
                except ValueError:
                    user.experience_years = 0
            
            if 'bio' in request.POST:
                user.bio = request.POST.get('bio', user.bio)
            
            if 'specialization' in request.POST:
                user.specialization = request.POST.get('specialization', user.specialization)
            
            # Handle password change
            current_password = request.POST.get('current_password')
            new_password = request.POST.get('new_password')
            confirm_password = request.POST.get('confirm_password')
            
            if current_password and new_password and confirm_password:
                if new_password != confirm_password:
                    return JsonResponse({
                        'success': False,
                        'message': 'New passwords do not match'
                    }, status=400)
                
                if not check_password(current_password, user.password):
                    return JsonResponse({
                        'success': False,
                        'message': 'Current password is incorrect'
                    }, status=400)
                
                if len(new_password) < 8:
                    return JsonResponse({
                        'success': False,
                        'message': 'New password must be at least 8 characters long'
                    }, status=400)
                
                user.set_password(new_password)
            
            # Handle profile image upload
            if 'profile_image' in request.FILES:
                profile_image = request.FILES['profile_image']
                # Validate file size (max 5MB)
                if profile_image.size > 5 * 1024 * 1024:
                    return JsonResponse({
                        'success': False,
                        'message': 'Profile image must be less than 5MB'
                    }, status=400)
                
                # Validate file type
                allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp']
                if profile_image.content_type not in allowed_types:
                    return JsonResponse({
                        'success': False,
                        'message': 'Only JPEG, PNG, GIF, and WebP images are allowed'
                    }, status=400)
                
                # Save the image
                file_name = f'profile_images/user_{user.id}_{profile_image.name}'
                file_path = default_storage.save(file_name, profile_image)
                user.profile_image = file_path
            
            user.save()
            
            return JsonResponse({
                'success': True,
                'message': 'Profile updated successfully',
                'user': {
                    'name': user.name,
                    'email': user.email,
                    'profile_image_url': user.profile_image.url if user.profile_image else None
                }
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Error updating profile: {str(e)}'
            }, status=500)
    
    return JsonResponse({
        'success': False,
        'message': 'Invalid request method'
    }, status=405)

@login_required
def create_assignment(request, user):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            
            # Validate required fields
            required_fields = ['chapter_id', 'due_date', 'description', 'student_class']
            for field in required_fields:
                if not data.get(field):
                    return JsonResponse({'success': False, 'error': f'{field} is required'}, status=400)
            
            # Get chapter
            chapter = get_object_or_404(Chapter, id=data['chapter_id'])
            
            # Parse the due date
            due_date = datetime.strptime(data['due_date'], "%Y-%m-%dT%H:%M")
            
            # Create assignment
            assignment = Homework.objects.create(
                chapter=chapter,
                description=data['description'],
                student_class=data['student_class'],
                due_date=due_date,
                school=user.assigned_school,
                trainer=user,
                assigned_date=timezone.now()
            )
            
            return JsonResponse({
                'success': True,
                'message': 'Assignment created successfully!',
                'assignment_id': assignment.id
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)}, status=400)
    
    return JsonResponse({'success': False, 'error': 'Invalid request method'}, status=405)

@login_required
def get_chapters(request):
    chapters = Chapter.objects.all().values('id', 'title', 'student_class')
    return JsonResponse(list(chapters), safe=False)
    
@login_required
def chapter(request, user):
    chapters = Chapter.objects.filter(student_class=user.student_class)
    return render(request, 'chapter1.html', {'user': user, 'chapters': chapters})


@login_required
def update(request, user):
    """
    View for displaying the daily task update page with trainer information
    """
    try:
        if not isinstance(user, Trainer):
            return redirect('login')
            
        # Get trainer's school information
        school = user.assigned_school
        school_name = school.name if school else "No School Assigned"
        
        # Prepare context with all necessary user data
        context = {
            'trainer': user,
            'user': user,
            'school_name': school_name,
            'is_trainer': True,
            'profile_image': user.profile_image.url if user.profile_image else '/static/default_profile.png',
            'today': timezone.now().date().isoformat(),
            'trainer_id': user.id  # Add this line to pass trainer_id to template
        }
        
        return render(request, 'update.html', context)
        
    except Exception as e:
        messages.error(request, f"Error loading update page: {str(e)}")
        return redirect('dashboard')


@login_required
def get_daily_updates(request, user):
    """
    API endpoint for fetching daily updates with user verification
    """
    if request.method == 'GET':
        try:
            year = int(request.GET.get('year'))
            month = int(request.GET.get('month'))  # JS sends 0-11, Python expects 1-12
            
            # Correct month handling (JS: 0-11 -> Python: 1-12)
            py_month = month + 1
            
            first_day = date(year, py_month, 1)
            if py_month == 12:
                last_day = date(year+1, 1, 1) - timedelta(days=1)
            else:
                last_day = date(year, py_month+1, 1) - timedelta(days=1)

            updates = DailyTaskUpdate.objects.filter(
                trainer=user,
                date__range=(first_day, last_day)
            ).order_by('date')

            updates_data = {}
            for update in updates:
                updates_data[update.date.isoformat()] = {
                    'text': update.update_text or '',
                    'time': update.submission_time.strftime("%I:%M %p"),
                    'image': update.update_image.url if update.update_image else None,
                    'status': update.status,
                }
            
            return JsonResponse(updates_data)
            
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)

@login_required
def save_daily_update(request, user):
    """
    API endpoint for saving daily updates with user verification
    """
    if request.method == 'POST':
        try:
            date_str = request.POST.get('date')
            update_text = request.POST.get('text')
            is_today = request.POST.get('is_today', 'false') == 'true'
            image_file = request.FILES.get('image')

            # Date parsing
            date_obj = datetime.strptime(date_str, '%Y-%m-%d').date()
            
            # Update or create record
            daily_update, created = DailyTaskUpdate.objects.update_or_create(
                trainer=user,
                date=date_obj,
                defaults={
                    'update_text': update_text,
                    'status': 'present' if is_today else 'requested',
                    'is_requested_update': not is_today,
                    'submission_time': timezone.now()
                }
            )

            # Handle image upload
            if image_file:
                daily_update.update_image = image_file
                daily_update.save()

            return JsonResponse({
                'success': True, 
                'message': 'Update saved successfully',
                'timestamp': daily_update.submission_time.strftime("%b %d, %I:%M %p")
            })
            
        except Exception as e:
            return JsonResponse({'success': False, 'message': str(e)}, status=500)
    
    return JsonResponse({'success': False, 'message': 'Invalid request method'}, status=405)


@login_required
def videotutorials(request, user, *args, **kwargs):  # Add 'user' parameter from decorator
    if request.method == "POST":
        # Existing POST handling remains the same
        chapter_selection = request.POST.get('chapter')
        if chapter_selection == 'new':
            chapter_name = request.POST.get('new_chapter')
        else:
            chapter_name = chapter_selection

        title = request.POST.get('title')
        video_url = request.POST.get('video_url')
        description = request.POST.get('description')

        chapter, created = Chapter.objects.get_or_create(
            title=chapter_name,
            defaults={'student_class': 'General'}
        )

        VideoTutorial.objects.create(
            chapter=chapter,
            title=title,
            video_url=video_url,
            description=description
        )
        return redirect('videotutorials')

    # GET request handling
    tutorials = VideoTutorial.objects.all().order_by('-created_at')
    chapters = Chapter.objects.all()
    
    # Determine user type
    is_trainer = hasattr(user, 'trainer')

    context = {
        'tutorials': tutorials,
        'chapters': chapters,
        'user': user,  # Pass the logged-in user to template
        'is_student': isinstance(user, student),  # Add this line
        'is_trainer': is_trainer,    }
    return render(request, 'video-tutorials.html', context)


@login_required
def resource_list(request, user):
    resources = Resource.objects.all()
    return render(request, 'resources.html', {
        'resources': resources,
        'user': user
    })


@login_required
def live(request, user, *args, **kwargs):  # Add 'user' parameter from decorator
    error_message = None
    if request.method == 'POST':
        if 'create' in request.POST:
            # Use the passed 'user' (student instance) as host
            room = LiveClassRoom.objects.create(host=user)
            room.participants.add(user)
            cache.set(room.room_id, [], timeout=3600)
            return redirect('live_room', room_id=room.room_id)
        elif 'join' in request.POST:
            room_id = request.POST.get('room_id', '').strip()
            if not room_id:
                error_message = "Please enter a Room ID."
            else:
                try:
                    room = LiveClassRoom.objects.get(room_id=room_id)
                    room.participants.add(user)
                    return redirect('live_room', room_id=room.room_id)
                except LiveClassRoom.DoesNotExist:
                    error_message = "Room ID does not exist. Please check and try again."
    
    rooms = LiveClassRoom.objects.all().order_by('-id')[:3]
    return render(request, 'home_live.html', {
        'error_message': error_message,
        'rooms': rooms,
        'user': user,
        'is_student': isinstance(user, student),  # Add this line

    })


@login_required
def live_room(request, user, room_id):
    """
    Renders the live room after verifying that the room exists.
    """
    room = get_object_or_404(LiveClassRoom, room_id=room_id)
    return render(request, 'live_room.html', {
        'user': user,
        'room': room,
        'room_id': room.room_id,
    })


@csrf_exempt
def signaling(request, room_id):
    """
    Handles WebRTC signaling messages.
    """
    # Verify that the room exists before processing signaling data
    try:
        LiveClassRoom.objects.get(room_id=room_id)
    except LiveClassRoom.DoesNotExist:
        return JsonResponse({'error': 'Room does not exist'}, status=404)
    
    if request.method == 'POST':
        data = json.loads(request.body)
        messages_list = cache.get(room_id, [])
        messages_list.append(data)
        cache.set(room_id, messages_list, timeout=3600)
        return JsonResponse({'status': 'success'})
    
    elif request.method == 'GET':
        messages_list = cache.get(room_id, [])
        return JsonResponse({'messages': messages_list})
    
    return JsonResponse({'error': 'Invalid method'}, status=405)


@login_required
def participants_count(request, user, room_id):
    room = get_object_or_404(LiveClassRoom, room_id=room_id)
    return JsonResponse({'count': room.participants.count()})


# ======================= Updated Project Views =======================

@login_required
def project(request, user):
    """
    Displays projects and processes project uploads.
    Accepts an extra parameter to satisfy a custom wrapper.
    """
    if request.method == "POST":
        form = StudentProjectForm(request.POST, request.FILES)
        if form.is_valid():
            # Create the project instance without committing yet.
            project_instance = form.save(commit=False)
            # Use the provided 'user' (logged-in student) for the project.
            project_instance.student = user
            project_instance.save()
            messages.success(request, "Project uploaded successfully!")
            return redirect("project")
        else:
            messages.error(
                request, "There was an error in your submission. Please check the details."
            )
    else:
        form = StudentProjectForm()

    # Retrieve all projects, ordered by the latest submission first.
    projects = Project.objects.all().order_by("-submitted_at")
    return render(request, "project.html", {"form": form, "projects": projects, "user": user})


@login_required
def projectdetail(request, user):
    """
    Displays details for a specific project.
    Expects an 'id' parameter in the query string.
    """
    project_id = request.GET.get("id")
    project_obj = get_object_or_404(Project, id=project_id)
    
    # Count likes and comments.
    likes = project_obj.total_likes()  # using the helper method in the Project model.
    comments = project_obj.comments.count()  # assuming 'comments' is the related name in the Comment model.
    
    # Fetch the file URL if available. This lets the template decide how to render it.
    file_url = project_obj.file.url if project_obj.file else None

    context = {
        "project": project_obj,
        "file_url": file_url,
        "likes": likes,
        "comments": comments,
        "user": user
    }
    return render(request, "project-detail.html", context)



@login_required
def certification(request, user, *args, **kwargs):
    if request.method == 'POST':
        form = CertificateRequestForm(request.POST)
        if form.is_valid():
            certificate = form.save(commit=False)
            certificate.status = 'pending'  # Default status
            certificate.save()
            return JsonResponse({'status': 'success', 'message': 'Certificate request submitted successfully!'})
        else:
            return JsonResponse({'status': 'error', 'message': 'Invalid form submission.'}, status=400)

    students = student.objects.all()  # Adjust filter as needed (e.g. for the logged-in user)
    certificates = Certificate.objects.filter(student__in=students).order_by('-request_date')
    form = CertificateRequestForm()
    return render(request, 'Certification.html', {
        'form': form,
        'students': students,
        'achievements': Certificate.ACHIEVEMENT_CHOICES,
        'certificates': certificates,
        'user': user
    })

@login_required
def download_certificate(request, user, *args, **kwargs):
    certificate_number = kwargs.get('certificate_number')
    certificate = get_object_or_404(
        Certificate, certificate_number=certificate_number, status='issued'
    )
    return render(request, 'certificationimage.html', {'certificate': certificate, 'user': user})


@login_required
def leaderboard(request, user):
    return render(request, 'leaderboard.html', {'user': user})


@login_required
def notification(request, user):
    return render(request, 'notification.html', {'user': user})


@login_required
def examinstruction(request, user, exam_id):
    exam = get_object_or_404(Exam, id=exam_id)
    return render(request, 'instructions.html', {
        'user': user,
        'exam': exam
    })



@login_required
def ufm(request, user, exam_id):
    exam = get_object_or_404(Exam, id=exam_id)
    return render(request, 'ufm.html', {
        'user': user,
        'exam': exam
    })


@login_required
def exampaper(request, user, exam_id):
    exam = get_object_or_404(Exam, id=exam_id, student_class=user.student_class, school=user.school)
    questions = ExamQuestion.objects.filter(exam=exam)
    if request.method == 'POST':
        performance = StudentExamPerformance.objects.create(
            student=user,
            exam=exam,
            marks_obtained=0,
            test_date=timezone.now()
        )
        correct_answers = 0
        for question in questions:
            selected_answer = request.POST.get(f'q{question.id}', '').upper()
            is_correct = selected_answer == question.correct_answer
            StudentExamResponse.objects.create(
                student_exam_performance=performance,
                exam_question=question,
                selected_answer=selected_answer,
                result='C' if is_correct else 'I'
            )
            if is_correct:
                correct_answers += 1
        performance.marks_obtained = correct_answers * exam.marks_per_question
        performance.save()
        return redirect('exam')
    return render(request, 'exam.html', {'user': user, 'exam': exam, 'questions': questions})


@login_required
def exam_result_detail(request, user, performance_id):
    performance = get_object_or_404(StudentExamPerformance, id=performance_id, student=user)
    responses = StudentExamResponse.objects.filter(student_exam_performance=performance)
    return render(request, 'result.html', {'user': user, 'performance': performance, 'responses': responses, 'exam': performance.exam})

@login_required
def exam_attempt_detail(request, performance_id):
    try:
        # Get the performance with related data
        performance = get_object_or_404(
            StudentExamPerformance.objects.select_related(
                'student', 'exam'
            ), 
            id=performance_id
        )
        
        # Get all responses for this performance with the related exam questions
        responses = StudentExamResponse.objects.filter(
            student_exam_performance=performance
        ).select_related('exam_question')
        
        # Check if the user has permission to view this attempt
        user = request.user
        is_authorized = False
        
        # Superusers and staff can view all
        if hasattr(user, 'is_superuser') and user.is_superuser:
            is_authorized = True
        elif hasattr(user, 'is_staff') and user.is_staff:
            is_authorized = True
        # Student can view their own attempts
        elif hasattr(user, 'student') and performance.student.id == user.id:
            is_authorized = True
        # Trainer can view attempts from their assigned school
        elif hasattr(user, 'trainer') and user.trainer.assigned_school == performance.student.school:
            is_authorized = True
        
        if not is_authorized:
            return HttpResponseForbidden("You don't have permission to view this exam attempt.")
        
        # Calculate percentage if not already set
        if not hasattr(performance, 'percentage') or performance.percentage is None:
            if performance.exam.total_marks > 0:
                performance.percentage = (performance.marks_obtained / performance.exam.total_marks) * 100
            else:
                performance.percentage = 0
        
        return render(request, 'exam_attempt_partial.html', {
            'performance': performance, 
            'responses': responses, 
            'exam': performance.exam
        })
        
    except Exception as e:
        logger.error(f"Error loading exam attempt: {str(e)}")
        return HttpResponse(
            f'<div class="alert alert-danger">Error loading exam details: {str(e)}</div>',
            status=500
        )
@login_required
def setting(request):
    # Check if user is authenticated
    if not request.user.is_authenticated:
        messages.error(request, 'Please log in to access settings.')
        return redirect('login')
    
    # Determine if user is a student or trainer
    user = request.user
    user_obj = None
    is_trainer = False
    
    try:
        # Try to get trainer profile
        try:
            user_obj = Trainer.objects.get(user_ptr=user)
            is_trainer = True
        except Trainer.DoesNotExist:
            pass
        
        # If not trainer, try to get student profile
        if not user_obj:
            try:
                user_obj = student.objects.get(user_ptr=user)
                is_trainer = False
            except student.DoesNotExist:
                pass
        
        # If still no profile found
        if not user_obj:
            messages.error(request, 'User profile not found. Please contact administrator.')
            logout(request)
            return redirect('login')
            
    except Exception as e:
        messages.error(request, f'Error accessing user profile: {str(e)}')
        return redirect('home')
    
    # Get or create user profile
    try:
        if is_trainer:
            profile, created = UserProfile.objects.get_or_create(trainer=user_obj)
        else:
            profile, created = UserProfile.objects.get_or_create(student=user_obj)
    except Exception as e:
        messages.error(request, f'Error accessing profile settings: {str(e)}')
        profile = None
    
    # Rest of the view remains the same as above...
    if request.method == 'POST':
        # Handle form submission
        if 'details_form' in request.POST and profile:
            try:
                # Update basic details
                profile.first_name = request.POST.get('fname', '')
                profile.last_name = request.POST.get('lname', '')
                profile.phone = request.POST.get('phone', '')
                profile.zip_code = request.POST.get('zip', '')
                profile.bio = request.POST.get('bio', '')
                
                # Handle profile image upload
                if 'profile_image' in request.FILES:
                    profile_image = request.FILES['profile_image']
                    # Delete old image if exists
                    if user_obj.profile_image:
                        if default_storage.exists(user_obj.profile_image.name):
                            default_storage.delete(user_obj.profile_image.name)
                    # Save new image
                    file_path = f'profile_images/{user_obj.id}_{profile_image.name}'
                    user_obj.profile_image = file_path
                    with default_storage.open(file_path, 'wb+') as destination:
                        for chunk in profile_image.chunks():
                            destination.write(chunk)
                
                # Handle cover image upload
                if 'cover_image' in request.FILES:
                    cover_image = request.FILES['cover_image']
                    # Delete old image if exists
                    if profile.cover_image:
                        if default_storage.exists(profile.cover_image.name):
                            default_storage.delete(profile.cover_image.name)
                    # Save new image
                    file_path = f'cover_images/{user_obj.id}_{cover_image.name}'
                    profile.cover_image = file_path
                    with default_storage.open(file_path, 'wb+') as destination:
                        for chunk in cover_image.chunks():
                            destination.write(chunk)
                
                profile.save()
                user_obj.save()
                messages.success(request, 'Profile updated successfully!')
                
            except Exception as e:
                messages.error(request, f'Error updating profile: {str(e)}')
            
        elif 'password_form' in request.POST:
            # Handle password change
            try:
                current_password = request.POST.get('current-password')
                new_password = request.POST.get('new-password')
                confirm_password = request.POST.get('confirm-password')
                
                if user_obj.check_password(current_password):
                    if new_password == confirm_password:
                        if len(new_password) >= 8:
                            user_obj.password = make_password(new_password)
                            user_obj.save()
                            messages.success(request, 'Password changed successfully!')
                        else:
                            messages.error(request, 'Password must be at least 8 characters long!')
                    else:
                        messages.error(request, 'New passwords do not match!')
                else:
                    messages.error(request, 'Current password is incorrect!')
                    
            except Exception as e:
                messages.error(request, f'Error changing password: {str(e)}')
                
        return redirect('setting')
    
    context = {
        'user': user_obj,
        'profile': profile,
        'is_trainer': is_trainer
    }
    
    return render(request, 'setting.html', context)

@login_required
def course(request, user):
    return render(request, 'course.html', {'user': user})
 
@login_required
def resetpassword(request, user):
    return render(request, 'reset-password1.html', {'user': user})

@login_required
def verifyemail(request, user):
    return render(request, 'forgot-password1.html', {'user': user})

@login_required
def studentlist(request, user):
    class_filter = request.GET.get('class')
    school_filter = request.GET.get('school')
    section_filter = request.GET.get('section')  # NEW

    students_qs = student.objects.all().select_related('school')

    if class_filter:
        students_qs = students_qs.filter(student_class=class_filter)
    if school_filter:
        students_qs = students_qs.filter(school_id=school_filter)
    if section_filter:
        students_qs = students_qs.filter(section=section_filter)

    paginator = Paginator(students_qs, 10)  # show 10 students per page
    page = request.GET.get('page')
    students = paginator.get_page(page)

    classes = student.objects.values_list('student_class', flat=True).distinct()
    schools = School.objects.all()
    sections = student.objects.values_list('section', flat=True).distinct()  # NEW

    return render(request, 'students.html', {
        'user': user,
        'students': students,
        'classes': classes,
        'schools': schools,
        'sections': sections   # NEW
    })

@login_required
def load_more_students(request):
    offset = int(request.GET.get('offset', 0))
    limit = 10  # Number of students to load per request
    
    class_filter = request.GET.get('class')
    school_filter = request.GET.get('school')
    section_filter = request.GET.get('section')
    
    students_qs = student.objects.all().select_related('school')
    
    if class_filter:
        students_qs = students_qs.filter(student_class=class_filter)
    if school_filter:
        students_qs = students_qs.filter(school_id=school_filter)
    if section_filter:
        students_qs = students_qs.filter(section=section_filter)
    
    # Get additional students
    more_students = students_qs[offset:offset + limit]
    
    # Prepare student data for JSON response
    students_data = []
    for student_obj in more_students:
        students_data.append({
            'name': student_obj.name,
            'student_class': student_obj.student_class,
            'section': student_obj.section,
            'email': student_obj.email,
            'course': student_obj.course,
            'enrollment_date': student_obj.enrollment_date.strftime('%Y-%m-%d'),
            'status': student_obj.status,
            'school_name': student_obj.school.name if student_obj.school else 'Not assigned'
        })
    
    return JsonResponse({
        'students': students_data,
        'has_more': len(more_students) == limit
    })

# Get all unique classes in a school
def get_classes(request, school_id):
    classes = (
        student.objects.filter(school_id=school_id)
        .values_list("student_class", flat=True)
        .distinct()
    )
    return JsonResponse(list(classes), safe=False)

# Get all unique sections of a class in a school
def get_sections(request, school_id, student_class):
    sections = (
        student.objects.filter(school_id=school_id, student_class=student_class)
        .values_list("section", flat=True)
        .distinct()
    )
    return JsonResponse(list(sections), safe=False)



# ============================================================================
# Updated Exam List View: Display only exams for the logged-in student's class and school
# ============================================================================
@login_required
def exam_list(request, user):
    if isinstance(user, Trainer):
        # Trainer view - get all exams from their assigned school
        exams = Exam.objects.filter(school=user.assigned_school)
        # For trainers, we don't need the attempted/performance data
        context = {
            'exams': exams,
            'user': user,
            'is_trainer': True
        }
    else:
        # Student view - only their class and school
        exams = Exam.objects.filter(
            student_class=user.student_class, 
            school=user.school
        )
        # Get student's exam performances
        attempted_exams = StudentExamPerformance.objects.filter(student=user)
        exam_performances = {attempt.exam.id: attempt for attempt in attempted_exams}
        
        # Add attempted/performance data to each exam
        for exam in exams:
            if exam.id in exam_performances:
                exam.attempted = True
                exam.performance = exam_performances[exam.id]
                exam.score = exam_performances[exam.id].marks_obtained
            else:
                exam.attempted = False
                
        context = {
            'exams': exams,
            'user': user,
            'is_trainer': False
        }
    
    return render(request, 'mainexam.html', context)


@login_required
def edit_exam(request, user, exam_id):
    # Common base query
    exam_query = Exam.objects.filter(id=exam_id)
    
    if isinstance(user, Trainer):
        # For trainers: only allow editing exams from their assigned school
        exam = get_object_or_404(exam_query, school=user.assigned_school)
    else:
        # For students: only allow editing exams from their class and school
        exam = get_object_or_404(
            exam_query,
            student_class=user.student_class,
            school=user.school
        )

    if request.method == 'POST':
        exam_form = ExamForm(request.POST, instance=exam)
        question_formset = ExamQuestionFormSet(request.POST, instance=exam)
        if exam_form.is_valid() and question_formset.is_valid():
            exam_form.save()
            question_formset.save()
            return redirect('exam')
    else:
        exam_form = ExamForm(instance=exam)
        question_formset = ExamQuestionFormSet(instance=exam)
    
    context = {
        'user': user,
        'exam': exam,
        'exam_form': exam_form,
        'question_formset': question_formset,
        'is_trainer': isinstance(user, Trainer)
    }
    return render(request, 'edit_exam.html', context)


@login_required
@require_POST
def delete_exam(request, user, exam_id):
    # Only trainers/staff/superusers can delete exams
    is_trainer = isinstance(user, Trainer)
    is_staff_or_super = getattr(user, 'is_staff', False) or getattr(user, 'is_superuser', False)

    if not (is_trainer or is_staff_or_super):
        messages.error(request, "You do not have permission to delete exams.")
        return redirect('exam')

    # Superusers/staff: can delete any exam
    if is_staff_or_super and not is_trainer:
        exam = get_object_or_404(Exam, id=exam_id)
    else:
        # Trainers: can delete only exams of their assigned school
        school = getattr(user, 'assigned_school', None)
        if not school:
            messages.error(request, "No school is assigned to your trainer profile.")
            return redirect('exam')
        exam = get_object_or_404(Exam, id=exam_id, school=school)

    exam.delete()
    messages.success(request, "Exam deleted successfully!")
    return redirect('exam')
    
@login_required
def discussionforum(request, user):  # Add 'user' parameter to match the decorator
    discussions = Discussion.objects.all().prefetch_related(
        'comments', 'likes', 'student'
    ).order_by('-created_at')
    return render(request, 'discussion-forum.html', {
        'discussions': discussions,
        'user': user  # Pass the user to the template
    })

@login_required
@require_POST
def create_discussion(request):
    try:
        data = json.loads(request.body)
        content = data.get('content', '').strip()
        if not content:
            return JsonResponse({'success': False, 'error': 'Content cannot be empty'}, status=400)
        
        discussion = Discussion.objects.create(
            student=request.user,
            content=content
        )
        return JsonResponse({
            'success': True,
            'discussion': {
                'id': discussion.id,
                'content': discussion.content,
                'author': request.user.get_full_name() or request.user.username,
                'timestamp': discussion.created_at.strftime("%b %d, %Y %I:%M %p"),
                'likes_count': 0,
                'comments_count': 0,
                'profile_image': request.user.profile_image.url if request.user.profile_image else '/static/default_profile.png'
            }
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

@login_required
@require_POST
def post_comment(request, discussion_id):
    try:
        data = json.loads(request.body)
        content = data.get('content', '').strip()
        if not content:
            return JsonResponse({'success': False, 'error': 'Content cannot be empty'}, status=400)
        
        discussion = get_object_or_404(Discussion, id=discussion_id)
        comment = Comment.objects.create(
            student=request.user,
            discussion=discussion,
            content=content
        )
        return JsonResponse({
            'success': True,
            'comment': {
                'id': comment.id,
                'content': comment.content,
                'author': request.user.get_full_name() or request.user.username,
                'timestamp': comment.created_at.strftime("%b %d, %Y %I:%M %p"),
                'profile_image': request.user.profile_image.url if request.user.profile_image else '/static/default_profile.png'
            }
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

@login_required
@require_POST
def toggle_like(request, discussion_id):
    try:
        discussion = get_object_or_404(Discussion, id=discussion_id)
        if request.user in discussion.likes.all():
            discussion.likes.remove(request.user)
            action = 'unliked'
        else:
            discussion.likes.add(request.user)
            action = 'liked'
        
        return JsonResponse({
            'success': True,
            'action': action,
            'likes_count': discussion.likes.count()
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)

@login_required
def homework(request, user):
    """
    Fetch homework assignments for the logged-in student's class and school.
    Only assignments that match the student's class and the student's school are shown.
    """
    student_class = user.student_class
    school = user.school  # Logged-in student's school
    now_time = timezone.now()

    current_assignments = Homework.objects.filter(
        student_class=student_class,
        school=school,
        due_date__gte=now_time,
        due_date__lte=now_time + timedelta(days=1)
    ).order_by('due_date')

    upcoming_assignments = Homework.objects.filter(
        student_class=student_class,
        school=school,
        due_date__gt=now_time + timedelta(days=1)
    ).order_by('due_date')

    past_homework = Homework.objects.filter(
        student_class=student_class,
        school=school,
        due_date__lt=now_time
    ).order_by('-due_date')

    context = {
        'current_assignments': current_assignments,
        'upcoming_assignments': upcoming_assignments,
        'past_homework': past_homework,
        'user': user
    }
    return render(request, 'homework.html', context)

@login_required
def student_results(request, user, *args, **kwargs):
    # Get the trainer object for the logged-in user
    try:
        trainer = Trainer.objects.get(email=user.email)
    except Trainer.DoesNotExist:
        # If not a trainer, return empty results
        results = StudentExamPerformance.objects.none()
        exams = Exam.objects.none()
        classes = []
        sections = []
        
        context = {
            'results': Paginator(results, 10).get_page(1),
            'exams': exams,
            'classes': classes,
            'sections': sections,
            'passed_count': 0,
            'failed_count': 0,
            'student_count': 0,
            'user': user
        }
        return render(request, 'studentresults.html', context)
    
    # Get the school assigned to the trainer
    assigned_school = trainer.assigned_school
    
    # Get sorting and filtering parameters from the query string
    sort_by = request.GET.get('sort', '')
    exam_filter = request.GET.get('exam', '')
    class_filter = request.GET.get('class', '')
    section_filter = request.GET.get('section', '')
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')
    marks_min = request.GET.get('marks_min', '')
    marks_max = request.GET.get('marks_max', '')
    percentage_min = request.GET.get('percentage_min', '')
    percentage_max = request.GET.get('percentage_max', '')
    status_filter = request.GET.get('status', '')
    
    # Query exam performances for students in the assigned school
    if assigned_school:
        results = StudentExamPerformance.objects.filter(
            student__school=assigned_school
        )
    else:
        # If no school assigned, return empty results
        results = StudentExamPerformance.objects.none()
    
    # Filter by exam if selected
    if exam_filter:
        results = results.filter(exam__id=exam_filter)
    
    # Filter by class if selected
    if class_filter:
        results = results.filter(student__student_class=class_filter)
    
    # Filter by section if selected
    if section_filter:
        results = results.filter(student__section=section_filter)
    
    # Filter by date range if selected
    if date_from:
        results = results.filter(exam__exam_date__gte=date_from)
    if date_to:
        results = results.filter(exam__exam_date__lte=date_to)
    
    # Annotate each result with a computed percentage field
    results = results.annotate(
        percentage=ExpressionWrapper(
            F('marks_obtained') * 100.0 / F('exam__total_marks'),
            output_field=FloatField()
        )
    )
    
    # Filter by marks range if selected
    if marks_min:
        results = results.filter(marks_obtained__gte=marks_min)
    if marks_max:
        results = results.filter(marks_obtained__lte=marks_max)
    
    # Filter by percentage range if selected
    if percentage_min:
        results = results.filter(percentage__gte=percentage_min)
    if percentage_max:
        results = results.filter(percentage__lte=percentage_max)
    
    # Filter by status (pass/fail) if selected
    if status_filter:
        if status_filter == 'pass':
            results = results.filter(percentage__gte=40)
        elif status_filter == 'fail':
            results = results.filter(percentage__lt=40)
    
    # Apply ordering based on the selected sort option
    if sort_by:
        if sort_by == 'exam_date':
            results = results.order_by('exam__exam_date')
        elif sort_by == 'exam_name':
            results = results.order_by('exam__title')
        elif sort_by == 'total_marks':
            results = results.order_by('exam__total_marks')
        elif sort_by == 'marks_obtained':
            results = results.order_by('marks_obtained')
        elif sort_by == 'percentage':
            results = results.order_by('percentage')
    else:
        # Default ordering: newest exam first
        results = results.order_by('-exam__exam_date')
    
    # Calculate statistics
    total_results = results.count()
    
    # Count passed students (>= 40%)
    passed_count = results.filter(percentage__gte=40).count()
    
    # Count failed students (< 40%)
    failed_count = results.filter(percentage__lt=40).count()
    
    # Count unique students
    if assigned_school:
        student_count = student.objects.filter(school=assigned_school).count()
    else:
        student_count = 0
    
    # Paginate the results (10 items per page)
    page_number = request.GET.get('page', 1)
    paginator = Paginator(results, 10)
    page_obj = paginator.get_page(page_number)
    
    # Get all exams for the filter dropdown (only for assigned school)
    if assigned_school:
        exams = Exam.objects.filter(school=assigned_school)
    else:
        exams = Exam.objects.none()
    
    # Get all classes for students in the assigned school
    # Create a list of class objects with id and name attributes
    if assigned_school:
        # Get distinct class values from students
        class_values = student.objects.filter(
            school=assigned_school
        ).values_list('student_class', flat=True).distinct()
        
        # Create class objects with id and name attributes
        classes = []
        for class_name in class_values:
            classes.append({
                'id': class_name,  # Using class name as ID since we don't have a Class model
                'name': class_name
            })
    else:
        classes = []
    
    # Get all sections for students in the assigned school
    # Create a list of section objects with id and name attributes
    if assigned_school:
        # Get distinct section values from students
        section_values = student.objects.filter(
            school=assigned_school,
            section__isnull=False
        ).exclude(section='').values_list('section', flat=True).distinct()
        
        # Create section objects with id and name attributes
        sections = []
        for section_name in section_values:
            sections.append({
                'id': section_name,
                'name': section_name
            })
    else:
        sections = []
    
    context = {
        'results': page_obj,
        'exams': exams,
        'classes': classes,
        'sections': sections,
        'passed_count': passed_count,
        'failed_count': failed_count,
        'student_count': student_count,
        'user': user
    }
    return render(request, 'studentresults.html', context)

@login_required
def chapter_detail(request, user, chapter_id):
    chapter = get_object_or_404(Chapter, id=chapter_id)
    resources = Resource.objects.filter(chapter=chapter)
    return render(request, 'chapter_detail.html', {
        'chapter': chapter,
        'resources': resources,
        'user': user 
    })

# views.py (simplified context handling)
# views.py (simplified context handling)
@login_required
def salary_dashboard(request, user):
    if not isinstance(user, Trainer):
            return redirect('login')
    today = date.today()
    current_month = today.replace(day=1)  # ✅ FIXED: first day of current month
    current_salary = Salary.objects.filter(trainer=user, month=current_month).first()
    salary_history = Salary.objects.filter(trainer=user).order_by('-month')[:12]

    # Only calculate breakdown if salary exists
    breakdown = None
    if current_salary:
        breakdown = {
            'full_basic': float(current_salary.basic),
            'prorated_basic': float(current_salary.prorated_basic),
            'hra': float(current_salary.hra),
            'allowances': float(current_salary.allowances),
            'tax': float(current_salary.tax),
            'pf': float(current_salary.pf),
            'other_deductions': float(current_salary.other_deductions),
            'net': float(current_salary.net_salary)
        }

    context = {
        'current_salary': current_salary,
        'employee_name': user.name,
        'current_month': current_month.strftime('%B %Y'),
        'gross_salary': current_salary.gross_salary if current_salary else 0,
        'deductions': current_salary.total_deductions if current_salary else 0,
        'net_salary': current_salary.net_salary if current_salary else 0,
        'status': current_salary.status if current_salary else 'unavailable',
        'salary_history': [{
            'month': s.month.strftime('%B %Y'),
            'full_basic': float(s.basic),
            'prorated_basic': float(s.prorated_basic),
            'hra': float(s.hra),
            'allowances': float(s.allowances),
            'tax': float(s.tax),
            'pf': float(s.pf),
            'other_deductions': float(s.other_deductions),
            'gross': float(s.gross_salary),
            'net': float(s.net_salary),
            'status': s.status,
            'present_days': s.present_days,
            'payment_date': s.payment_date.strftime('%d %b %Y') if s.payment_date else '-'
        } for s in salary_history],
        'breakdown': breakdown,
        'school_name': user.assigned_school.name if user.assigned_school else "No School Assigned",
        'profile_image': user.profile_image.url if user.profile_image else '/static/default_profile.png',
        'trainer': user,
        'user': user,
        'is_trainer': True,
        'today': timezone.now().date().isoformat(),
        'trainer_id': user.id
    }

    return render(request, 'salary.html', context)

@login_required
def import_students(request, user):
    if not isinstance(user, Trainer):
        return redirect('login')

    if request.method == 'POST' and request.FILES.get('csv_file'):
        excel_file = request.FILES['csv_file']
        if not excel_file.name.endswith('.xlsx'):
            messages.error(request, "Uploaded file is not an Excel (.xlsx) file.")
            return redirect('import_students')

        try:
            wb = openpyxl.load_workbook(excel_file)
            sheet = wb.active

            success_count = 0
            error_rows = []

            headers = [cell.value for cell in sheet[1]]  # Get header row
            for row_idx, row in enumerate(sheet.iter_rows(min_row=2, values_only=True), start=2):
                try:
                    row_data = dict(zip(headers, row))

                    dob = datetime.strptime(str(row_data['dob']).strip(), "%d-%m-%Y").date()
                    enrollment_date = datetime.strptime(str(row_data['enrollment_date']).strip(), "%d-%m-%Y").date()

                    school_id = row_data.get('school_id')
                    school = School.objects.filter(pk=int(school_id)).first() if school_id else None

                    student.objects.update_or_create(
                        email=str(row_data['email']).strip(),
                        defaults={
                            'name': str(row_data['name']).strip(),
                            'password': make_password(str(row_data['password']).strip()),
                            'enrollment': str(row_data['enrollment']).strip(),
                            'course': str(row_data['course']).strip(),
                            'dob': dob,
                            'enrollment_date': enrollment_date,
                            'student_class': str(row_data['student_class']).strip(),
                            'section': str(row_data.get('section', '')).strip() if row_data.get('section') else None,
                            'school': school,
                        }
                    )
                    success_count += 1
                except Exception as e:
                    error_rows.append(f"Row {row_idx}: {e}")

            messages.success(request, f"Successfully imported {success_count} students.")
            if error_rows:
                messages.warning(request, f"{len(error_rows)} rows skipped due to errors.")
                for msg in error_rows[:5]:
                    messages.warning(request, msg)

        except Exception as e:
            messages.error(request, f"Error processing file: {e}")

        return redirect('import_students')

    return render(request, 'import_students.html', {'user': user})


@login_required
def add_student(request, user):
    if not isinstance(user, Trainer):
        return redirect('login')

    if request.method == "POST":
        try:
            name = request.POST.get("name")
            email = request.POST.get("email")
            password = request.POST.get("password")
            enrollment = request.POST.get("enrollment")
            course = request.POST.get("course")
            dob = request.POST.get("dob")   # yyyy-mm-dd format (from HTML input type="date")
            enrollment_date = request.POST.get("enrollment_date")
            student_class = request.POST.get("student_class")
            school_id = request.POST.get("school")
            profile_image = request.FILES.get('profile_image')

            school = School.objects.filter(pk=school_id).first() if school_id else None

            # Convert date strings
            dob = datetime.strptime(dob, "%Y-%m-%d").date() if dob else None
            enrollment_date = datetime.strptime(enrollment_date, "%Y-%m-%d").date() if enrollment_date else None

            # Create or update student
            student_obj, created = student.objects.update_or_create(
                email=email.strip(),
                defaults={
                    "name": name.strip(),
                    "password": make_password(password.strip()),
                    "enrollment": enrollment.strip(),
                    "course": course.strip(),
                    "dob": dob,
                    "enrollment_date": enrollment_date,
                    "student_class": student_class.strip(),
                    "school": school,
                }
            )

            # Handle profile image
            if profile_image:
                student_obj.profile_image = profile_image
            elif not student_obj.profile_image:  # Set default only if no image exists
                student_obj.profile_image = 'profileimage/icon.png'
            
            student_obj.save()

            messages.success(request, f"Student '{name}' {'created' if created else 'updated'} successfully.")
            return redirect("add_student")

        except Exception as e:
            messages.error(request, f"Error adding student: {str(e)}")
            return redirect("add_student")

    schools = School.objects.all()
    return render(request, "add_student.html", {
        "user": user, 
        "schools": schools,
        "today": datetime.now().strftime("%Y-%m-%d")  # For setting default enrollment date
    })

def export_students_csv(request):
    class_filter = request.GET.get("class")
    school_filter = request.GET.get("school")

    students = student.objects.all()
    if class_filter:
        students = students.filter(student_class=class_filter)
    if school_filter:
        students = students.filter(school=school_filter)

    # Prepare CSV response
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="students.csv"'

    writer = csv.writer(response)
    writer.writerow(['Name', 'Email', 'Course', 'Enrollment Date', 'Status', 'Class', 'School'])

    for student in students:
        writer.writerow([
            student.name,
            student.email,
            student.course,
            student.enrollment_date,
            student.status,
            student.student_class,
            student.school
        ])

    return response



@login_required
def document(request, user):
    """
    Document upload view for trainers
    """
    
    # Check if user is a Trainer (following your pattern from salary_dashboard)
    if not isinstance(user, Trainer):
        return redirect('login')
    
    trainer = user  # user is already a Trainer object
    
    # Get or create progress tracker
    progress, created = DocumentUploadProgress.objects.get_or_create(trainer=trainer)
    if created:
        progress.update_progress()
    
    # Get all document types
    document_types = DocumentType.objects.all().prefetch_related('fields')
    
    # Get uploaded documents by this trainer
    uploaded_documents = TrainerDocument.objects.filter(trainer=trainer).select_related('document_type')
    
    # Prepare document data for template
    documents_data = []
    for doc_type in document_types:
        existing_doc = uploaded_documents.filter(document_type=doc_type).first()
        
        # Prepare fields data
        fields_data = []
        for field in doc_type.fields.all():
            field_dict = {
                'name': field.name,
                'label': field.label,
                'type': field.field_type,
                'required': field.is_required,
                'pattern': field.pattern if field.pattern else '',
                'min': field.min_value,
                'max': field.max_value,
                'options': field.options if field.options else []
            }
            fields_data.append(field_dict)
        
        # Get existing form data if document exists
        form_data = {}
        if existing_doc and existing_doc.form_data:
            form_data = existing_doc.form_data
        
        document_info = {
            'id': doc_type.id,
            'title': doc_type.name,
            'description': doc_type.description,
            'required': doc_type.is_required,
            'category': doc_type.get_category_display(),
            'fields': fields_data,
            'status': existing_doc.status if existing_doc else 'pending',
            'uploaded_at': existing_doc.submitted_at.strftime('%Y-%m-%d %H:%M:%S') if existing_doc else None,
            'verified_at': existing_doc.verified_at.strftime('%Y-%m-%d %H:%M:%S') if existing_doc and existing_doc.verified_at else None,
            'document_id': str(existing_doc.id) if existing_doc else None,
            'file_name': existing_doc.document_file.name.split('/')[-1] if existing_doc and existing_doc.document_file else None,
            'file_url': existing_doc.document_file.url if existing_doc and existing_doc.document_file else None,
            'form_data': form_data,
            'rejection_reason': existing_doc.rejection_reason if existing_doc else ''
        }
        documents_data.append(document_info)
    
    # Group documents by category
    documents_by_category = {}
    for doc in documents_data:
        category = doc['category']
        if category not in documents_by_category:
            documents_by_category[category] = []
        documents_by_category[category].append(doc)
    
    # Prepare context
    context = {
        'user': user,
        'trainer': trainer,
        'documents_data': documents_data,
        'documents_by_category': documents_by_category,
        'documents_json': json.dumps(documents_data, default=str, ensure_ascii=False),
        'progress': progress,
        'uploaded_documents': uploaded_documents,
        'total_required': DocumentType.objects.filter(is_required=True).count(),
        'total_uploaded': uploaded_documents.filter(status__in=['submitted', 'verified']).count(),
        'completed_percentage': progress.completion_percentage,
        'is_trainer': True,  # Add this like in salary_dashboard
        'profile_image': trainer.profile_image.url if trainer.profile_image else '/static/default_profile.png',
    }
    
    return render(request, 'document.html', context)

@login_required
@require_POST
def upload_document(request, user):
    """
    Handle document upload via AJAX
    """
    try:
        # Check if user is a Trainer
        if not isinstance(user, Trainer):
            return JsonResponse({'success': False, 'error': 'User is not a trainer'})
        
        data = request.POST
        files = request.FILES
        
        document_type_id = data.get('document_type_id')
        form_data_json = data.get('form_data', '{}')
        
        if not document_type_id:
            return JsonResponse({'success': False, 'error': 'Document type is required'})
        
        # Get document type
        try:
            document_type = DocumentType.objects.get(id=document_type_id)
        except DocumentType.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Invalid document type'})
        
        trainer = user
        
        # Check if file is uploaded
        if 'document_file' not in files:
            return JsonResponse({'success': False, 'error': 'Document file is required'})
        
        document_file = files['document_file']
        
        # Validate file size (5MB max)
        if document_file.size > 5 * 1024 * 1024:
            return JsonResponse({
                'success': False, 
                'error': 'File size exceeds 5MB limit'
            })
        
        # Validate file extension
        allowed_extensions = ['pdf', 'jpg', 'jpeg', 'png']
        file_extension = document_file.name.split('.')[-1].lower()
        if file_extension not in allowed_extensions:
            return JsonResponse({
                'success': False,
                'error': f'File type not allowed. Allowed types: {", ".join(allowed_extensions)}'
            })
        
        # Parse form data
        try:
            form_data = json.loads(form_data_json)
        except json.JSONDecodeError:
            form_data = {}
        
        # Validate form fields
        fields = document_type.fields.all()
        for field in fields:
            if field.is_required and field.name not in form_data:
                return JsonResponse({
                    'success': False,
                    'error': f'{field.label} is required'
                })
        
        # Check if document already exists for this type
        existing_doc = TrainerDocument.objects.filter(
            trainer=trainer,
            document_type=document_type
        ).first()
        
        if existing_doc:
            # Update existing document
            existing_doc.document_file = document_file
            existing_doc.form_data = form_data
            existing_doc.status = 'submitted'
            existing_doc.submitted_at = timezone.now()
            existing_doc.rejection_reason = ''  # Clear rejection reason on re-submission
            existing_doc.save()
            document = existing_doc
        else:
            # Create new document
            document = TrainerDocument.objects.create(
                trainer=trainer,
                document_type=document_type,
                document_file=document_file,
                form_data=form_data,
                status='submitted'
            )
        
        # Update progress
        progress, _ = DocumentUploadProgress.objects.get_or_create(trainer=trainer)
        progress.update_progress()
        
        return JsonResponse({
            'success': True,
            'message': 'Document uploaded successfully',
            'document': {
                'id': str(document.id),
                'type': document_type.name,
                'status': document.status,
                'uploaded_at': document.submitted_at.strftime('%Y-%m-%d %H:%M:%S'),
                'file_name': document_file.name,
                'file_size': f"{document_file.size / 1024:.1f} KB",
            },
            'progress': {
                'completed': progress.completed_documents_count,
                'required': progress.required_documents_count,
                'percentage': progress.completion_percentage,
                'display': progress.get_progress_display()
            }
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

@login_required
@csrf_exempt
@require_POST
def delete_document(request, user):
    """
    Delete an uploaded document
    """
    try:
        # Check if user is a Trainer
        if not isinstance(user, Trainer):
            return JsonResponse({'success': False, 'error': 'User is not a trainer'})
        
        data = json.loads(request.body)
        document_id = data.get('document_id')
        
        if not document_id:
            return JsonResponse({'success': False, 'error': 'Document ID is required'})
        
        # Get and delete document
        document = get_object_or_404(TrainerDocument, id=document_id, trainer=user)
        document_type_name = document.document_type.name
        
        # Delete the document file from storage
        document.document_file.delete(save=False)
        
        # Delete the document record
        document.delete()
        
        # Update progress
        progress, _ = DocumentUploadProgress.objects.get_or_create(trainer=user)
        progress.update_progress()
        
        return JsonResponse({
            'success': True,
            'message': f'{document_type_name} document deleted successfully',
            'progress': {
                'completed': progress.completed_documents_count,
                'required': progress.required_documents_count,
                'percentage': progress.completion_percentage,
                'display': progress.get_progress_display()
            }
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False,
            'error': str(e)
        })

@login_required
def view_document(request, user, document_id):
    """
    View a specific document
    """
    # Check if user is a Trainer
    if not isinstance(user, Trainer):
        return redirect('login')
    
    trainer = user
    
    # Get document with proper filtering
    try:
        document = TrainerDocument.objects.get(
            id=document_id,
            trainer=trainer
        )
    except TrainerDocument.DoesNotExist:
        return redirect('document')
    
    fields = document.document_type.fields.all()
    
    # Prepare form data for easy access in template
    form_items = []
    for field in fields:
        value = document.form_data.get(field.name, 'Not provided')
        form_items.append({
            'label': field.label,
            'value': value if value else 'Not provided'
        })
    
    context = {
        'user': trainer,
        'trainer': trainer,
        'document': document,
        'fields': fields,
        'form_items': form_items,  # Use this instead of form_data
        'form_data': document.form_data,  # Keep original for backward compatibility
        'is_trainer': True,
        'profile_image': (
            trainer.profile_image.url
            if trainer.profile_image else
            '/static/default_profile.png'
        ),
    }
    
    return render(request, 'view_document.html', context)


def update_progress(self):
    required_types_qs = DocumentType.objects.filter(is_required=True)
    self.required_documents_count = required_types_qs.count()

    completed_count = TrainerDocument.objects.filter(
        trainer=self.trainer,
        status__in=['submitted', 'verified'],
        document_type__in=required_types_qs
    ).values('document_type').distinct().count()

    self.completed_documents_count = completed_count
    self.save()
# ==================== COUNSELING VIEWS ====================

@login_required
def counseling_dashboard(request, user):
    """Counseling dashboard for trainers"""
    if not isinstance(user, Trainer):
        messages.error(request, "Only trainers can access counseling dashboard.")
        return redirect('dashboard')
    
    # Get sessions for this trainer
    sessions = CounselingSession.objects.filter(counselor=user).order_by('-date_of_session')[:5]
    
    # Statistics
    total_sessions = CounselingSession.objects.filter(counselor=user).count()
    active_sessions = CounselingSession.objects.filter(counselor=user, status='in_progress').count()
    completed_sessions = CounselingSession.objects.filter(counselor=user, status='completed').count()
    locked_sessions = CounselingSession.objects.filter(counselor=user, status='locked').count()
    
    # Recent student counseling records
    recent_records = StudentCounselingRecord.objects.filter(
        counseling_session__counselor=user
    ).select_related('student', 'counseling_session').order_by('-created_at')[:10]
    
    context = {
        'user': user,
        'sessions': sessions,
        'total_sessions': total_sessions,
        'active_sessions': active_sessions,
        'completed_sessions': completed_sessions,
        'locked_sessions': locked_sessions,
        'recent_records': recent_records,
        'is_trainer': True
    }
    return render(request, 'counseling_dashboard.html', context)

@login_required
def counseling_session_list(request, user):
    """List all counseling sessions for the trainer"""
    if not isinstance(user, Trainer):
        messages.error(request, "Only trainers can access counseling sessions.")
        return redirect('dashboard')
    
    # Filter parameters
    status_filter = request.GET.get('status', '')
    school_filter = request.GET.get('school', '')
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')
    
    sessions = CounselingSession.objects.filter(counselor=user)
    
    # Apply filters
    if status_filter:
        sessions = sessions.filter(status=status_filter)
    if school_filter:
        sessions = sessions.filter(school_id=school_filter)
    if date_from:
        sessions = sessions.filter(date_of_session__gte=date_from)
    if date_to:
        sessions = sessions.filter(date_of_session__lte=date_to)
    
    sessions = sessions.select_related('school').prefetch_related('student_counselings').order_by('-date_of_session')
    
    # Pagination
    paginator = Paginator(sessions, 10)
    page = request.GET.get('page')
    sessions_page = paginator.get_page(page)
    
    context = {
        'user': user,
        'sessions': sessions_page,
        'status_choices': CounselingSession.STATUS_CHOICES,
        'schools': School.objects.all(),
        'is_trainer': True
    }
    return render(request, 'counseling_session_list.html', context)

@login_required
def counseling_session_create(request, user):
    """Create a new counseling session"""
    if not isinstance(user, Trainer):
        messages.error(request, "Only trainers can create counseling sessions.")
        return redirect('dashboard')
    
    # Define CLASS_CHOICES locally for the template
    class_choices = [
        ('Class 1', 'Class 1'),
        ('Class 2', 'Class 2'),
        ('Class 3', 'Class 3'),
        ('Class 4', 'Class 4'),
        ('Class 5', 'Class 5'),
        ('Class 6', 'Class 6'),
        ('Class 7', 'Class 7'),
        ('Class 8', 'Class 8'),
        ('Class 9', 'Class 9'),
        ('Class 10', 'Class 10'),
        ('General', 'General'),
    ]
    
    if request.method == 'POST':
        try:
            # Get form data
            school_id = request.POST.get('school')
            date_of_session = request.POST.get('date_of_session')
            student_class = request.POST.get('student_class')
            section = request.POST.get('section')
            session_notes = request.POST.get('session_notes', '')
            
            print(f"DEBUG: Form data - school_id: {school_id}, class: {student_class}, section: {section}")
            
            # Validate required fields
            if not all([school_id, date_of_session, student_class, section]):
                messages.error(request, "Please fill all required fields.")
                return redirect('counseling_session_create')
            
            # Create session
            session = CounselingSession.objects.create(
                counselor=user,
                school_id=school_id,
                date_of_session=date_of_session,
                student_class=student_class,
                section=section,
                session_notes=session_notes,
                status='draft'
            )
            
            messages.success(request, f"Counseling session created successfully! Now add students to the session.")
            return redirect('add_students_to_session', session_id=session.id)
            
        except Exception as e:
            messages.error(request, f"Error creating session: {str(e)}")
            return redirect('counseling_session_create')
    
    context = {
        'user': user,
        'schools': School.objects.all(),
        'class_choices': class_choices,
        'today': timezone.now().date().isoformat(),
        'is_trainer': True
    }
    return render(request, 'counseling_session_create.html', context)


@login_required
def counseling_session_detail(request, user, session_id):
    """View details of a counseling session"""
    session = get_object_or_404(CounselingSession, id=session_id)
    
    # Check permissions
    if not isinstance(user, Trainer) or session.counselor != user:
        messages.error(request, "You don't have permission to view this session.")
        return redirect('counseling_session_list')
    
    student_records = session.student_counselings.all().select_related('student')
    
    # Statistics
    total_students = student_records.count()
    robotics_interested = student_records.filter(interested_in_robotics='Y').count()
    parent_involved = student_records.filter(parent_involvement='Y').count()
    
    # Calculate average interest level
    interest_levels = student_records.exclude(interest_level__isnull=True).values_list('interest_level', flat=True)
    avg_interest = sum(interest_levels) / len(interest_levels) if interest_levels else 0
    
    context = {
        'user': user,
        'session': session,
        'student_records': student_records,
        'total_students': total_students,
        'robotics_interested': robotics_interested,
        'parent_involved': parent_involved,
        'avg_interest': round(avg_interest, 1),
        'is_trainer': True
    }
    return render(request, 'counseling_session_detail.html', context)

@login_required
def counseling_session_update(request, user, session_id):
    """Update a counseling session"""
    session = get_object_or_404(CounselingSession, id=session_id)
    
    # Check permissions and if session is locked
    if not isinstance(user, Trainer) or session.counselor != user:
        messages.error(request, "You don't have permission to update this session.")
        return redirect('counseling_session_list')
    
    if session.is_locked():
        messages.error(request, "Cannot update a locked session.")
        return redirect('counseling_session_detail', session_id=session.id)
    
    if request.method == 'POST':
        try:
            session_notes = request.POST.get('session_notes', '')
            session.session_notes = session_notes
            session.save()
            
            messages.success(request, "Session updated successfully!")
            return redirect('counseling_session_detail', session_id=session.id)
            
        except Exception as e:
            messages.error(request, f"Error updating session: {str(e)}")
    
    context = {
        'user': user,
        'session': session,
        'is_trainer': True
    }
    return render(request, 'counseling_session_update.html', context)

@login_required
def error_page(request, user, path=None):
    """Handle all undefined URLs"""
    user = request.user  # Get the logged-in user from request
    
    # Determine user type
    is_trainer = hasattr(user, 'trainer')
    is_student = hasattr(user, 'student')  # Assuming you have a student profile model
    
    context = {
        'user': user,  # Pass the logged-in user to template
        'is_trainer': is_trainer,
        'is_student': is_student,
        'requested_path': request.path,
    }
    return render(request, 'error.html', context, status=404)


@login_required
def start_counseling_session(request, user, session_id):
    """Start a counseling session (change status from draft to in_progress)"""
    session = get_object_or_404(CounselingSession, id=session_id)
    
    # Check permissions
    if not isinstance(user, Trainer) or session.counselor != user:
        messages.error(request, "You don't have permission to start this session.")
        return redirect('counseling_session_list')
    
    if session.status == 'draft':
        session.status = 'in_progress'
        session.save()
        messages.success(request, "Counseling session started! You can now conduct counseling.")
    else:
        messages.info(request, "Session is already in progress.")
    
    return redirect('counseling_session_detail', session_id=session.id)

@login_required
def add_students_to_session(request, user, session_id):
    """Add students to a counseling session"""
    session = get_object_or_404(CounselingSession, id=session_id)
    
    # Check permissions and if session is locked
    if not isinstance(user, Trainer) or session.counselor != user:
        messages.error(request, "You don't have permission to add students to this session.")
        return redirect('counseling_session_list')
    
    if session.is_locked():
        messages.error(request, "Cannot add students to a locked session.")
        return redirect('counseling_session_detail', session_id=session.id)
    
    if request.method == 'POST':
        try:
            student_ids = request.POST.getlist('students')
            added_count = 0
            
            for student_id in student_ids:
                student_obj = get_object_or_404(student, id=student_id)
                # Check if student is already in session
                if not StudentCounselingRecord.objects.filter(
                    counseling_session=session, student=student_obj
                ).exists():
                    StudentCounselingRecord.objects.create(
                        counseling_session=session,
                        student=student_obj
                    )
                    added_count += 1
            
            if added_count > 0:
                messages.success(request, f"Successfully added {added_count} students to the session.")
            else:
                messages.info(request, "No new students were added.")
            
            return redirect('counseling_session_detail', session_id=session.id)
            
        except Exception as e:
            messages.error(request, f"Error adding students: {str(e)}")
    
    # Get available students for this class and section
    available_students = student.objects.filter(
        student_class=session.student_class,
        section=session.section,
        school=session.school
    ).exclude(
        counseling_records__counseling_session=session
    )
    
    context = {
        'user': user,
        'session': session,
        'available_students': available_students,
        'is_trainer': True
    }
    return render(request, 'add_students_to_session.html', context)

@login_required
def lock_counseling_session(request, user, session_id):
    """Lock a counseling session"""
    session = get_object_or_404(CounselingSession, id=session_id)
    
    # Check permissions
    if not isinstance(user, Trainer) or session.counselor != user:
        messages.error(request, "You don't have permission to lock this session.")
        return redirect('counseling_session_list')
    
    if session.is_locked():
        messages.warning(request, "Session is already locked.")
    else:
        session.lock_session()
        messages.success(request, "Session locked successfully! No further changes can be made.")
    
    return redirect('counseling_session_detail', session_id=session.id)

@login_required
def complete_counseling_session(request, session_id):
    """
    Mark a counseling session as completed (status -> 'completed').
    Will auto-lock the session if it isn't locked already.
    Requires POST and permission (session counselor).
    """
    if request.method != 'POST':
        messages.error(request, "Invalid request method.")
        return redirect('counseling_session_detail', session_id=session_id)

    session = get_object_or_404(CounselingSession, id=session_id)

    trainer = _get_logged_trainer(request.user)
    if trainer is None or session.counselor != trainer:
        messages.error(request, "You don't have permission to complete this session.")
        return redirect('counseling_session_list')

    if session.status == 'completed':
        messages.warning(request, "Session is already completed.")
        return redirect('counseling_session_detail', session_id=session.id)

    try:
        with transaction.atomic():
            # ensure it's locked before completing — we set locked_at when locking
            if session.status != 'locked':
                session.status = 'locked'
                session.locked_at = timezone.now()
            session.status = 'completed'
            # keep locked_at (it may already be set)
            session.save(update_fields=['status', 'locked_at'])
    except Exception:
        messages.error(request, "Failed to complete the session. Try again.")
        return redirect('counseling_session_detail', session_id=session.id)

    messages.success(request, "Session marked as completed. No further changes are permitted.")
    return redirect('counseling_session_detail', session_id=session.id)


@login_required
def unlock_counseling_session(request, user, session_id):
    """Unlock a counseling session (admin/superuser only)"""
    session = get_object_or_404(CounselingSession, id=session_id)
    
    # Only superusers can unlock sessions
    if not getattr(user, 'is_superuser', False):
        messages.error(request, "Only administrators can unlock sessions.")
        return redirect('counseling_session_detail', session_id=session.id)
    
    if not session.is_locked():
        messages.warning(request, "Session is not locked.")
    else:
        session.unlock_session()
        messages.success(request, "Session unlocked successfully! Changes can now be made.")
    
    return redirect('counseling_session_detail', session_id=session.id)

@login_required
def student_counseling_record_update(request, user, record_id):
    """Update a student counseling record"""
    record = get_object_or_404(StudentCounselingRecord, id=record_id)
    
    # Check permissions and if session is locked
    if not isinstance(user, Trainer) or record.counseling_session.counselor != user:
        messages.error(request, "You don't have permission to update this record.")
        return redirect('counseling_session_list')
    
    if record.counseling_session.is_locked():
        messages.error(request, "Cannot update records in a locked session.")
        return redirect('counseling_session_detail', session_id=record.counseling_session.id)
    
    if request.method == 'POST':
        try:
            # Update record fields
            record.interested_in_robotics = request.POST.get('interested_in_robotics')
            record.interest_level = request.POST.get('interest_level')
            record.favorite_subject = request.POST.get('favorite_subject', '')
            record.career_aspiration = request.POST.get('career_aspiration', '')
            record.parent_involvement = request.POST.get('parent_involvement')
            record.parent_feedback = request.POST.get('parent_feedback', '')
            record.student_feedback = request.POST.get('student_feedback', '')
            record.counselor_notes = request.POST.get('counselor_notes', '')
            record.contact_number = request.POST.get('contact_number', '')
            
            record.save()
            
            messages.success(request, "Counseling record updated successfully!")
            return redirect('counseling_session_detail', session_id=record.counseling_session.id)
            
        except Exception as e:
            messages.error(request, f"Error updating record: {str(e)}")
    
    context = {
        'user': user,
        'record': record,
        'interest_level_choices': StudentCounselingRecord.INTEREST_LEVEL_CHOICES,
        'yes_no_choices': StudentCounselingRecord.YES_NO_CHOICES,
        'is_trainer': True
    }
    return render(request, 'student_counseling_record_update.html', context)

@login_required
def bulk_update_counseling_records(request, user):
    """Bulk update counseling records for a session"""
    if not isinstance(user, Trainer):
        messages.error(request, "Only trainers can update counseling records.")
        return redirect('dashboard')
    
    if request.method == 'POST':
        try:
            session_id = request.POST.get('session_id')
            session = get_object_or_404(CounselingSession, id=session_id, counselor=user)
            
            if session.is_locked():
                messages.error(request, "Cannot update records in a locked session.")
                return redirect('counseling_session_detail', session_id=session_id)
            
            records_updated = 0
            for key, value in request.POST.items():
                if key.startswith('record_'):
                    parts = key.split('_')
                    if len(parts) >= 3:
                        record_id = parts[1]
                        field_name = parts[2]
                        
                        try:
                            record = StudentCounselingRecord.objects.get(
                                id=record_id, counseling_session=session
                            )
                            
                            if field_name == 'interested_in_robotics' and value in ['Y', 'N']:
                                record.interested_in_robotics = value
                            elif field_name == 'interest_level' and value.isdigit():
                                record.interest_level = int(value)
                            elif field_name == 'favorite_subject':
                                record.favorite_subject = value
                            elif field_name == 'parent_involvement' and value in ['Y', 'N']:
                                record.parent_involvement = value
                            
                            record.save()
                            records_updated += 1
                            
                        except (StudentCounselingRecord.DoesNotExist, ValueError):
                            continue
            
            messages.success(request, f"Successfully updated {records_updated} records.")
            
        except Exception as e:
            messages.error(request, f"Error updating records: {str(e)}")
    
    return redirect('counseling_session_detail', session_id=session_id)

@login_required
def ajax_load_sections(request, user):
    """AJAX view to load sections based on school and class"""
    school_id = request.GET.get('school')
    student_class = request.GET.get('student_class')
    
    print(f"DEBUG AJAX: Received request - school: {school_id}, class: {student_class}")
    
    if not school_id or not student_class:
        print("DEBUG AJAX: Missing school or class parameters")
        return JsonResponse({
            'success': False, 
            'error': 'School and Class are required',
            'sections': []
        })
    
    try:
        # Convert to proper types
        school_id = int(school_id)
        student_class = str(student_class).strip()
        
        print(f"DEBUG AJAX: Querying for school_id={school_id}, class='{student_class}'")
        
        # Get distinct sections from students in the selected school and class
        students_with_sections = student.objects.filter(
            school_id=school_id,
            student_class=student_class
        ).exclude(
            section__isnull=True
        ).exclude(
            section=''
        ).values_list('section', flat=True).distinct().order_by('section')
        
        sections_list = list(students_with_sections)
        print(f"DEBUG AJAX: Found {len(sections_list)} sections: {sections_list}")
        
        # Also check what students exist for debugging
        student_count = student.objects.filter(
            school_id=school_id,
            student_class=student_class
        ).count()
        print(f"DEBUG AJAX: Total students in this school/class: {student_count}")
        
        return JsonResponse({
            'success': True,
            'sections': sections_list,
            'debug_info': {
                'student_count': student_count,
                'school_id': school_id,
                'student_class': student_class
            }
        })
        
    except Exception as e:
        print(f"DEBUG AJAX: Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return JsonResponse({
            'success': False, 
            'error': str(e),
            'sections': []
        })
@login_required
def ajax_load_students(request, user):
    """AJAX view to load students based on school, class, and section"""
    school_id = request.GET.get('school')
    student_class = request.GET.get('student_class')
    section = request.GET.get('section')
    
    print(f"DEBUG: Loading students for school={school_id}, class={student_class}, section={section}")
    
    if school_id and student_class and section:
        try:
            students_data = student.objects.filter(
                school_id=school_id,
                student_class=student_class,
                section=section
            ).values('id', 'name', 'email', 'enrollment', 'dob')
            
            students_list = list(students_data)
            print(f"DEBUG: Found {len(students_list)} students")
            
            return JsonResponse({'students': students_list})
            
        except Exception as e:
            print(f"DEBUG: Error loading students: {str(e)}")
            return JsonResponse({'students': [], 'error': str(e)})
    
    return JsonResponse({'students': []})

@login_required
def counseling_report(request, user):
    """Generate counseling reports"""
    if not isinstance(user, Trainer):
        messages.error(request, "Only trainers can access counseling reports.")
        return redirect('dashboard')
    
    # Filter parameters
    school_filter = request.GET.get('school', '')
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')
    
    sessions = CounselingSession.objects.filter(counselor=user)
    
    # Apply filters
    if school_filter:
        sessions = sessions.filter(school_id=school_filter)
    if date_from:
        sessions = sessions.filter(date_of_session__gte=date_from)
    if date_to:
        sessions = sessions.filter(date_of_session__lte=date_to)
    
    # Statistics
    total_sessions = sessions.count()
    total_students = StudentCounselingRecord.objects.filter(
        counseling_session__in=sessions
    ).count()
    
    # Interest statistics
    interest_stats = StudentCounselingRecord.objects.filter(
        counseling_session__in=sessions,
        interest_level__isnull=False
    ).aggregate(
        avg_interest=Avg('interest_level'),
        high_interest=Count('id', filter=Q(interest_level__gte=4))
    )
    
    # Robotics interest
    robotics_interested = StudentCounselingRecord.objects.filter(
        counseling_session__in=sessions,
        interested_in_robotics='Y'
    ).count()
    
    # Parent involvement
    parent_involved = StudentCounselingRecord.objects.filter(
        counseling_session__in=sessions,
        parent_involvement='Y'
    ).count()
    
    context = {
        'user': user,
        'sessions': sessions,
        'schools': School.objects.all(),
        'total_sessions': total_sessions,
        'total_students': total_students,
        'avg_interest': interest_stats['avg_interest'] or 0,
        'high_interest_count': interest_stats['high_interest'] or 0,
        'robotics_interested': robotics_interested,
        'parent_involved': parent_involved,
        'is_trainer': True
    }
    return render(request, 'counseling_report.html', context)

@login_required
def get_unread_notification_count(request):
    """Get unread notification count for AJAX requests"""
    try:
        user = get_logged_in_user(request)
        if not user:
            return JsonResponse({'count': 0})
        
        unread_count = NotificationReceipt.objects.filter(
            recipient_content_type=ContentType.objects.get_for_model(user),
            recipient_object_id=user.id,
            is_read=False
        ).count()
        
        return JsonResponse({'count': unread_count})
    except Exception as e:
        return JsonResponse({'count': 0})

@login_required
def notification_list(request):
    """Display all notifications for the logged-in user"""
    user = get_logged_in_user(request)
    if not user:
        return render(request, 'notification_list.html', {'notifications': [], 'unread_count': 0})
    
    # Get notification receipts for this user
    receipts = NotificationReceipt.objects.filter(
        recipient_content_type=ContentType.objects.get_for_model(user),
        recipient_object_id=user.id
    ).select_related('notification').order_by('-created_at')
    
    # Mark all as delivered when viewing the full list
    for receipt in receipts.filter(delivered=False):
        receipt.mark_delivered()
    
    unread_count = receipts.filter(is_read=False).count()
    
    context = {
        'receipts': receipts,
        'unread_count': unread_count,
        'user': user
    }
    return render(request, 'notification_list.html', context)

@login_required
@require_POST
def mark_notification_read(request, notification_id):
    """Mark a specific notification as read for the current user"""
    try:
        user = get_logged_in_user(request)
        if not user:
            return JsonResponse({'success': False, 'error': 'User not authenticated'})
        
        # Get the receipt for this user and notification
        receipt = get_object_or_404(
            NotificationReceipt,
            notification_id=notification_id,
            recipient_content_type=ContentType.objects.get_for_model(user),
            recipient_object_id=user.id
        )
        
        receipt.mark_read()
        
        return JsonResponse({'success': True})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
@require_POST
def mark_all_notifications_read(request):
    """Mark all notifications as read for the current user"""
    try:
        user = get_logged_in_user(request)
        if not user:
            return JsonResponse({'success': False, 'error': 'User not authenticated'})
        
        # Get all unread receipts for this user and mark them as read
        receipts = NotificationReceipt.objects.filter(
            recipient_content_type=ContentType.objects.get_for_model(user),
            recipient_object_id=user.id,
            is_read=False
        )
        
        for receipt in receipts:
            receipt.mark_read()
        
        return JsonResponse({'success': True, 'marked_read': receipts.count()})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
def get_recent_notifications(request):
    """Get recent notifications for AJAX requests (dropdown)"""
    try:
        user = get_logged_in_user(request)
        if not user:
            return JsonResponse({'notifications': []})
        
        # Get recent notification receipts for this user (unread first, then by date)
        receipts = NotificationReceipt.objects.filter(
            recipient_content_type=ContentType.objects.get_for_model(user),
            recipient_object_id=user.id
        ).select_related('notification').order_by('is_read', '-created_at')[:10]
        
        # Mark as delivered when fetched for dropdown
        for receipt in receipts.filter(delivered=False):
            receipt.mark_delivered()
        
        notifications_data = []
        for receipt in receipts:
            notification = receipt.notification
            notifications_data.append({
                'id': notification.id,
                'receipt_id': receipt.id,
                'title': notification.title,
                'message': notification.message,
                'type': notification.notification_type,
                'priority': notification.priority,
                'created_at': receipt.created_at.strftime("%b %d, %Y %I:%M %p"),
                'is_read': receipt.is_read,
                'action_url': notification.action_url,
                'action_text': notification.action_text
            })
        
        return JsonResponse({'notifications': notifications_data})
    except Exception as e:
        print(f"Error in get_recent_notifications: {str(e)}")  # For debugging
        return JsonResponse({'notifications': []})
    


@login_required
def project_list(request, user):
    # user is either student or Trainer

    if isinstance(user, Trainer):
        return HttpResponseForbidden("Trainer cannot access Alpha Console projects")

    projects = CodingProject.objects.filter(student=user)

    return render(request, 'project_list.html', {
        'projects': projects,
        'user': user
    })


# =====================================================
# CREATE PROJECT (ASK MODE)
# =====================================================
@login_required
def create_project(request, user):

    if isinstance(user, Trainer):
        return HttpResponseForbidden("Trainer cannot create projects")

    if request.method == 'POST':
        title = request.POST.get('title')
        mode = request.POST.get('mode')

        project = CodingProject.objects.create(
            student=user,
            title=title,
            mode=mode
        )

        return redirect('alpha_console_editor', project_id=project.id)

    return render(request, 'create_project.html', {
        'user': user
    })


# =====================================================
# EDITOR PAGE
# =====================================================
@login_required
def editor(request, user, project_id):

    if isinstance(user, Trainer):
        return HttpResponseForbidden("Trainer cannot edit student projects")

    project = get_object_or_404(
        CodingProject,
        id=project_id,
        student=user
    )

    return render(request, 'editor.html', {
        'project': project,
        'user': user
    })


@login_required  # Your custom decorator
def save_project(request, user, project_id):
    """Save project - uses custom @login_required decorator"""
    try:
        print(f"DEBUG: User type in save_project: {type(user)}")
        print(f"DEBUG: User object: {user}")
        
        # Check if user is a student
        if isinstance(user, student):
            student_obj = user
        elif isinstance(user, Trainer):
            return JsonResponse({
                'success': False, 
                'error': 'Only students can save their own projects'
            }, status=403)
        else:
            return JsonResponse({
                'success': False, 
                'error': 'Invalid user type'
            }, status=403)
        
        # Get the project for this student
        try:
            project = CodingProject.objects.get(id=project_id, student=student_obj)
            print(f"DEBUG: Project found: {project.title}")
        except CodingProject.DoesNotExist:
            print(f"DEBUG: Project not found or permission denied")
            return JsonResponse({
                'success': False, 
                'error': 'Project not found or you do not have permission'
            }, status=404)
        
        if request.method != 'POST':
            return JsonResponse({'success': False, 'error': 'Invalid request'}, status=400)
        
        try:
            data = json.loads(request.body)
            print(f"DEBUG: Data received: {list(data.keys())}")
        except json.JSONDecodeError as e:
            print(f"DEBUG: JSON decode error: {e}")
            return JsonResponse({'success': False, 'error': f'Invalid JSON: {str(e)}'}, status=400)
        
        # Update project fields
        if 'language' in data:
            project.language = data['language']
            print(f"DEBUG: Set language to: {data['language']}")
        
        if 'board' in data:
            project.board = data['board']
            print(f"DEBUG: Set board to: {data['board']}")
        
        if 'block_data' in data:
            project.block_data = data['block_data']
            print(f"DEBUG: Set block_data (type: {type(data['block_data'])})")
        
        if 'text_code' in data:
            project.text_code = data['text_code']
            print(f"DEBUG: Set text_code (length: {len(data['text_code']) if data['text_code'] else 0})")
        
        if 'sprite_data' in data:
            project.sprite_data = data['sprite_data']
            print(f"DEBUG: Set sprite_data")
        
        if 'backdrop' in data:
            project.backdrop = data['backdrop']
            print(f"DEBUG: Set backdrop to: {data['backdrop']}")
        
        project.updated_at = timezone.now()
        print(f"DEBUG: Set updated_at to: {project.updated_at}")
        
        try:
            project.save()
            print(f"DEBUG: Project saved successfully!")
            
            return JsonResponse({
                'success': True,
                'message': 'Project saved successfully',
                'updated_at': project.updated_at.strftime('%Y-%m-%d %H:%M:%S')
            })
            
        except Exception as save_error:
            print(f"DEBUG: Save error: {save_error}")
            import traceback
            print(f"DEBUG: Traceback: {traceback.format_exc()}")
            return JsonResponse({
                'success': False, 
                'error': f'Save failed: {str(save_error)}'
            }, status=500)
        
    except Exception as e:
        print(f"DEBUG: Unexpected error: {e}")
        import traceback
        print(f"DEBUG: Traceback: {traceback.format_exc()}")
        return JsonResponse({
            'success': False, 
            'error': f'Unexpected error: {str(e)}'
        }, status=500)


@login_required
def upload_to_board(request, user):
    """
    Handle code upload to connected board
    """
    try:
        if not request.body:
            return JsonResponse({"success": False, "error": "No data provided"}, status=400)
        
        data = json.loads(request.body)
        board = data.get('board')
        code = data.get('code')
        language = data.get('language', 'arduino')
        
        if not board:
            return JsonResponse({"success": False, "error": "No board selected"}, status=400)
        
        if not code:
            return JsonResponse({"success": False, "error": "No code to upload"}, status=400)
        
        print(f"DEBUG: Uploading to {board}, language: {language}")
        print(f"DEBUG: Code length: {len(code)}")
        
        # For demo purposes - simulate upload
        # In production, you would:
        # 1. Save code to a file
        # 2. Use appropriate compiler (arduino-cli, esptool, uflash, etc.)
        # 3. Upload via serial, wifi, or bluetooth
        
        import time
        time.sleep(2)  # Simulate upload time
        
        # Log the upload
        print(f"UPLOAD LOG: Board={board}, Language={language}")
        print(f"CODE PREVIEW:\n{code[:500]}...")
        
        # For now, just return success
        return JsonResponse({
            "success": True,
            "message": f"Code uploaded successfully to {board}",
            "board": board,
            "language": language,
            "timestamp": timezone.now().isoformat()
        })
        
    except json.JSONDecodeError as e:
        return JsonResponse({"success": False, "error": f"Invalid JSON: {str(e)}"}, status=400)
    except Exception as e:
        print(f"Upload error: {e}")
        import traceback
        traceback.print_exc()
        return JsonResponse({"success": False, "error": str(e)}, status=500)

# =====================================================
# GET AVAILABLE DEVICES
# =====================================================
@login_required
def get_available_devices(request, user):
    """
    Return available devices for connection
    """
    try:
        connection_type = request.GET.get('type', 'usb')
        
        # Mock device data for demo
        # In production, you would scan for actual devices
        
        mock_devices = {
            'usb': [
                {'id': 'arduino_uno_com3', 'name': 'Arduino Uno', 'type': 'COM3', 'board': 'arduino_uno'},
                {'id': 'quarky_com4', 'name': 'Quarky Robot', 'type': 'COM4', 'board': 'quarky'},
                {'id': 'esp32_com5', 'name': 'ESP32 Dev Board', 'type': 'COM5', 'board': 'esp32'}
            ],
            'bluetooth': [
                {'id': 'hc05_bt', 'name': 'HC-05 Bluetooth', 'type': 'Bluetooth', 'board': 'arduino_uno'},
                {'id': 'quarky_bt', 'name': 'Quarky BT', 'type': 'Bluetooth', 'board': 'quarky'},
                {'id': 'microbit_bt', 'name': 'Micro:bit', 'type': 'Bluetooth', 'board': 'microbit'}
            ],
            'wifi': [
                {'id': 'esp32_wifi', 'name': 'ESP32-AP', 'type': 'Wi-Fi', 'board': 'esp32'},
                {'id': 'quarky_wifi', 'name': 'Quarky WIFI', 'type': 'Wi-Fi', 'board': 'quarky'}
            ]
        }
        
        devices = mock_devices.get(connection_type, [])
        
        return JsonResponse({
            "success": True,
            "devices": devices,
            "count": len(devices)
        })
        
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)

# =====================================================
# CONNECT TO DEVICE
# =====================================================
@login_required
def connect_device(request, user):
    """
    Establish connection with a device
    """
    try:
        data = json.loads(request.body)
        device_id = data.get('device_id')
        connection_type = data.get('connection_type')
        
        if not device_id or not connection_type:
            return JsonResponse({"success": False, "error": "Missing device ID or connection type"}, status=400)
        
        # Simulate connection
        # In production, you would:
        # 1. For USB: Open serial port
        # 2. For Bluetooth: Pair and connect
        # 3. For WiFi: Verify connection
        
        print(f"DEBUG: Connecting to device {device_id} via {connection_type}")
        
        # Return mock connection info
        return JsonResponse({
            "success": True,
            "message": "Device connected successfully",
            "device_id": device_id,
            "connection_type": connection_type,
            "status": "connected"
        })
        
    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=500)
    

# Store active connections
active_connections = {}

@csrf_exempt
def get_serial_ports(request):
    """Get available serial ports"""
    ports = []
    for port in serial.tools.list_ports.comports():
        ports.append({
            'name': port.name,
            'description': port.description,
            'device': port.device,
            'hwid': port.hwid
        })
    return JsonResponse({'ports': ports})

@csrf_exempt
def connect_serial(request):
    """Connect to serial port"""
    if request.method == 'POST':
        data = json.loads(request.body)
        port_name = data.get('port')
        baud_rate = data.get('baud', 9600)
        
        try:
            # Close existing connection if any
            if port_name in active_connections:
                active_connections[port_name].close()
            
            # Create new serial connection
            ser = serial.Serial(
                port=port_name,
                baudrate=baud_rate,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=1
            )
            
            active_connections[port_name] = ser
            
            return JsonResponse({
                'success': True,
                'message': f'Connected to {port_name}'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })

@csrf_exempt
def disconnect_serial(request):
    """Disconnect from serial port"""
    if request.method == 'POST':
        data = json.loads(request.body)
        port_name = data.get('port')
        
        if port_name in active_connections:
            active_connections[port_name].close()
            del active_connections[port_name]
            
        return JsonResponse({'success': True})

@csrf_exempt
def send_to_serial(request):
    """Send data to serial port"""
    if request.method == 'POST':
        data = json.loads(request.body)
        port_name = data.get('port')
        message = data.get('message')
        
        if port_name in active_connections:
            try:
                active_connections[port_name].write(message.encode())
                return JsonResponse({'success': True})
            except Exception as e:
                return JsonResponse({
                    'success': False,
                    'error': str(e)
                })
        
        return JsonResponse({
            'success': False,
            'error': 'Port not connected'
        })

@csrf_exempt
def read_from_serial(request):
    """Read data from serial port"""
    if request.method == 'POST':
        data = json.loads(request.body)
        port_name = data.get('port')
        
        if port_name in active_connections:
            try:
                if active_connections[port_name].in_waiting > 0:
                    data = active_connections[port_name].readline().decode().strip()
                    return JsonResponse({
                        'success': True,
                        'data': data
                    })
            except Exception as e:
                return JsonResponse({
                    'success': False,
                    'error': str(e)
                })
        
        return JsonResponse({
            'success': True,
            'data': ''
        })

# WebSocket server for ESP32/MicroPython boards
class WebSocketServer:
    def __init__(self):
        self.clients = set()
        self.message_queue = queue.Queue()
    
    async def handler(self, websocket, path):
        self.clients.add(websocket)
        client_ip = websocket.remote_address[0]
        print(f"New WebSocket connection from {client_ip}")
        
        try:
            async for message in websocket:
                print(f"Received: {message}")
                # Echo back or process message
                await websocket.send(f"Echo: {message}")
        finally:
            self.clients.remove(websocket)
            print(f"Connection closed from {client_ip}")
    
    def broadcast(self, message):
        for client in self.clients:
            asyncio.run(client.send(message))

@csrf_exempt
def connect_board(request):
    """Connect to a specific board"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            board_type = data.get('board')
            connection_type = data.get('connection_type', 'usb')
            device_info = data.get('device_info', {})
            
            print(f"Connecting to {board_type} via {connection_type}")
            print(f"Device info: {device_info}")
            
            # Board-specific connection validation
            board_requirements = {
                'arduino_uno': {
                    'usb': ['CH340', 'FTDI', 'Arduino'],
                    'bluetooth': ['HC-05', 'HC-06'],
                    'wifi': ['ESP-01', 'WiFi shield']
                },
                'esp32': {
                    'usb': ['CP2102', 'CH9102'],
                    'bluetooth': ['ESP32 Bluetooth'],
                    'wifi': ['ESP32 WiFi']
                },
                'microbit': {
                    'usb': ['MBED', 'DAPLink'],
                    'bluetooth': ['Micro:bit Bluetooth'],
                    'wifi': None  # Micro:bit doesn't have WiFi
                },
                'quarky': {
                    'usb': ['CH340', 'Quarky USB'],
                    'bluetooth': ['Quarky Bluetooth'],
                    'wifi': ['ESP8266', 'Quarky WiFi']
                }
            }
            
            # Validate connection
            if board_type not in board_requirements:
                return JsonResponse({
                    'success': False,
                    'error': f'Unsupported board type: {board_type}'
                })
            
            reqs = board_requirements[board_type]
            if connection_type not in reqs or reqs[connection_type] is None:
                return JsonResponse({
                    'success': False,
                    'error': f'{board_type} does not support {connection_type} connection'
                })
            
            # Generate connection ID
            connection_id = f"{board_type}_{connection_type}_{int(time.time())}"
            
            # Store connection
            active_connections[connection_id] = {
                'board': board_type,
                'connection_type': connection_type,
                'device_info': device_info,
                'connected_at': timezone.now(),
                'status': 'connected'
            }
            
            return JsonResponse({
                'success': True,
                'message': f'Connected to {board_type}',
                'connection_id': connection_id,
                'board': board_type,
                'connection_type': connection_type
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })

def process_code_for_board(code, board, language):
    """Process and format code for specific board"""
    
    # Remove stage-only blocks (like sprite movement) for hardware boards
    if language == 'javascript' and board != 'stage':
        # Filter out JavaScript functions that are only for stage/sprite
        lines = code.split('\n')
        filtered_lines = []
        stage_keywords = [
            'move(', 'turn(', 'goTo(', 'glide(', 'setDirection(',
            'changeXBy(', 'changeYBy(', 'setX(', 'setY(',
            'say(', 'think(', 'show(', 'hide(', 'switchCostume(',
            'playSound(', 'beep(', 'stopAllSounds(',
            'touching(', 'keyPressed(', 'mouseDown(', 'askAndWait('
        ]
        
        for line in lines:
            if not any(keyword in line for keyword in stage_keywords):
                filtered_lines.append(line)
        
        code = '\n'.join(filtered_lines)
    
    # Add board-specific headers and setup
    if board == 'arduino_uno':
        if language == 'arduino':
            code = f"""// Generated for Arduino Uno
// {time.strftime('%Y-%m-%d %H:%M:%S')}

{code}
"""
        elif language == 'javascript':
            # Convert JavaScript-like syntax to Arduino
            code = convert_js_to_arduino(code)
    
    elif board == 'esp32':
        if language == 'arduino':
            code = f"""// Generated for ESP32
// {time.strftime('%Y-%m-%d %H:%M:%S')}
#include <WiFi.h>

{code}
"""
    
    elif board == 'microbit':
        if language == 'python':
            code = f"""# Generated for Micro:bit
# {time.strftime('%Y-%m-%d %H:%M:%S')}
from microbit import *

{code}
"""
    
    elif board == 'quarky':
        if language == 'arduino':
            code = f"""// Generated for Quarky Robot
// {time.strftime('%Y-%m-%d %H:%M:%S')}
#include <Servo.h>
#include <NewPing.h>

{code}
"""
    
    return code

def convert_js_to_arduino(js_code):
    """Convert JavaScript-like syntax to Arduino C++"""
    # Simple conversions for demo
    replacements = [
        ('console.log(', 'Serial.println('),
        ('delay(', 'delay('),
        ('Math.random()', 'random()'),
        ('parseInt(', 'int('),
        ('parseFloat(', 'float('),
        ('true', 'true'),
        ('false', 'false'),
        ('null', 'NULL'),
        ('function ', 'void '),
        ('var ', 'int '),  # Simplified
        ('let ', 'int '),
        ('const ', 'const int '),
    ]
    
    for old, new in replacements:
        js_code = js_code.replace(old, new)
    
    return js_code

def simulate_usb_upload(filepath, board, config):
    """Simulate USB upload process"""
    try:
        print(f"Simulating USB upload for {board} at {config['baud_rate']} baud")
        print(f"File: {filepath}")
        
        # In real implementation, you would:
        # 1. Use avrdude for AVR boards (Arduino Uno, Quarky)
        # 2. Use esptool for ESP32
        # 3. Use uFlash for Micro:bit
        
        time.sleep(2)  # Simulate upload time
        
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": f"USB upload failed: {str(e)}"}

def simulate_wifi_upload(filepath, board, config, device_id):
    """Simulate WiFi upload process"""
    try:
        print(f"Simulating WiFi upload for {board} to device {device_id}")
        
        # In real implementation, you would:
        # 1. Upload via OTA (Over-the-Air) for ESP32
        # 2. Use HTTP POST to upload endpoint
        
        time.sleep(3)  # Simulate upload time
        
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": f"WiFi upload failed: {str(e)}"}

def simulate_bluetooth_upload(filepath, board, config, device_id):
    """Simulate Bluetooth upload process"""
    try:
        print(f"Simulating Bluetooth upload for {board} to device {device_id}")
        
        # In real implementation, you would:
        # 1. Use Bluetooth serial profile
        # 2. Use DAPLink for Micro:bit
        
        time.sleep(4)  # Simulate upload time
        
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": f"Bluetooth upload failed: {str(e)}"}


