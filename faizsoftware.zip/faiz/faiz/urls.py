"""
URL configuration for bqinfotech project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import re_path
from django.urls import path, include
from faiz import views
from django.conf import settings
from django.conf.urls.static import static  
from django.utils.timezone import now
from django.conf import settings
from .views import discussionforum, create_discussion, post_comment, toggle_like

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name="home"),
    path('change-password/', views.change_password, name='change_password'),
    path('login-auth-user/', views.login_view, name="login"),
    path('logout/', views.logout_view, name="logout"),
    path('dashboard-user/', views.dashboard, name="dashboard"),    
    path('create_assignment/', views.create_assignment, name='create_assignment'),
    path('update-trainer-profile/', views.update_trainer_profile, name='update_trainer_profile'),
    path('get_chapters/', views.get_chapters, name='get_chapters'),
    path('',views.home,name="home"),
    path('dashboard-user/daily-task-update/', views.update, name='update'),
    path('get_daily_updates/', views.get_daily_updates, name='get_daily_updates'),
    path('save_daily_update/', views.save_daily_update, name='save_daily_update'), 
    path('dashboard-user/discussionforum/', views.discussionforum, name='discussionforum'),
    path('discussions/create/', views.create_discussion, name='create_discussion'),
    path('discussions/<int:discussion_id>/comment/', views.post_comment, name='post_comment'),
    path('discussions/<int:discussion_id>/like/', views.toggle_like, name='toggle_like'),
    path('dashboard-user/video-tutorials/', views.videotutorials, name="videotutorials"),
    path('dashboard-user/resources/',views.resource_list,name="resources"),
    path('dashboard-user/resources/chapter/<int:chapter_id>/', views.chapter_detail, name='chapter_detail'),
    path('live-session/',views.live,name="live"),
    path('dashboard-user/user-project/', views.project, name="project"),
    path('dashboard-user/user-project/project-detail/', views.projectdetail, name="projectdetail"),
    path('dashboard-user/Certification/', views.certification, name='certification'),   
    path('dashboard-user/Certification/download-certificate/<str:certificate_number>/', views.download_certificate, name='download_certificate'),
    path('dashboard-user/leaderboard/',views.leaderboard,name="leaderboard"),
    path('notification/',views.notification,name="notification"),
    path('studentresults/',views.student_results,name="studentresults"),
    path('dashboard-user/exam-access-user/',views.exam_list,name="exam"),  # Make sure name="exam" exists    
    path('dashboard-user/exam-access-user/instruction/<int:exam_id>/', views.examinstruction, name="instruction"),
    path('dashboard-user/exam-access-user/instruction/ufm/<int:exam_id>/', views.ufm, name="ufm"),
    path('dashboard-user/exam-access-user/instruction/ufm/exampaper/<int:exam_id>/', views.exampaper, name="exampaper"),
    path('import-students/', views.import_students, name='import_students'),
    path('add-student/', views.add_student, name='add_student'),
    path('dashboard-user/exam-result/<int:performance_id>/', views.exam_result_detail, name='exam_result_detail'),    
    path('dashboard-user/course/',views.course,name="course"),
    path('dashboard-user/addexam/', views.add_exam, name="addexam"),
    path('dashboard-user/result/<int:performance_id>/', views.exam_result_detail, name="exam_result_detail"),
    path('dashboard-user/exam/result/<int:performance_id>/', views.exam_result_detail, name='exam_result_detail'),
    path('dashboard-user/edit_exam/<int:exam_id>/', views.edit_exam, name='edit_exam'),
    path('delete_exam/<int:exam_id>/', views.delete_exam, name='delete_exam'),
    path('dashboard-user/homework/', views.homework, name='homework'),
    path('dashboard-user/live/', views.live, name='live'),
    path('dashboard-user/live/<str:room_id>/', views.live_room, name='live_room'),
    path('signaling/<str:room_id>/', views.signaling, name='signaling'),
    path('homelive/', views.live_room, name='homelive'),
    path('participants_count/<str:room_id>/', views.participants_count, name='participants_count'),
    path('dashboard-user/setting/',views.setting,name="setting"),
    path('dashboard-user/students/',views.studentlist, name='students'),
    path('dashboard-user/salary/', views.salary_dashboard, name='salary_dashboard'),
    path('export/students/', views.export_students_csv, name='export_students_csv'),
    path('dashboard-user/resetpassword/',views.resetpassword, name='resetpassword'),
    path('dashboard-user/verifyemail/',views.verifyemail, name='verifyemail'),
    # Update all document URLs to not require user parameter:
    path('dashboard-user/documents/', views.document, name='document_list'),
    path('dashboard-user/documents/upload/', views.upload_document, name='upload_document'),
    path('dashboard-user/documents/delete/', views.delete_document, name='delete_document'),
    path('dashboard-user/documents/<uuid:document_id>/', views.view_document, name='view_document'),
    path('exam-attempt-detail/<int:performance_id>/', views.exam_attempt_detail, name='exam_attempt_detail'),
    path("get-classes/<int:school_id>/", views.get_classes, name="get_classes"),
    path("get-sections/<int:school_id>/<str:student_class>/", views.get_sections, name="get_sections"),
    path('load-more-students/', views.load_more_students, name='load_more_students'),
   # ==================== COUNSELING URLs ====================
    path('dashboard-user/counseling/', views.counseling_dashboard, name='counseling_dashboard'),
    path('dashboard-user/counseling/sessions/', views.counseling_session_list, name='counseling_session_list'),
    path('dashboard-user/counseling/sessions/create/', views.counseling_session_create, name='counseling_session_create'),
    path('dashboard-user/counseling/sessions/<int:session_id>/', views.counseling_session_detail, name='counseling_session_detail'),
    path('dashboard-user/counseling/sessions/<int:session_id>/update/', views.counseling_session_update, name='counseling_session_update'),
    path('dashboard-user/counseling/sessions/<int:session_id>/start/', views.start_counseling_session, name='start_counseling_session'),
    path('dashboard-user/counseling/sessions/<int:session_id>/add-students/', views.add_students_to_session, name='add_students_to_session'),
    path('dashboard-user/counseling/sessions/<int:session_id>/lock/', views.lock_counseling_session, name='lock_counseling_session'),
    path('dashboard-user/counseling/sessions/<int:session_id>/complate/', views.complete_counseling_session, name='complete_counseling_session'),
    path('dashboard-user/counseling/sessions/<int:session_id>/unlock/', views.unlock_counseling_session, name='unlock_counseling_session'),
    path('dashboard-user/counseling/records/<int:record_id>/update/', views.student_counseling_record_update, name='student_counseling_record_update'),
    path('dashboard-user/counseling/records/bulk-update/', views.bulk_update_counseling_records, name='bulk_update_counseling_records'),
    # Fix the AJAX URLs - remove 'counseling/' from the path
    path('dashboard-user/counseling/ajax/load-sections/', views.ajax_load_sections, name='ajax_load_sections'),
    path('dashboard-user/counseling/ajax/load-students/', views.ajax_load_students, name='ajax_load_students'),
    path('dashboard-user/counseling/reports/', views.counseling_report, name='counseling_report'),
    path('notifications/', views.notification_list, name='notification_list'),
    path('notifications/mark-read/<int:notification_id>/', views.mark_notification_read, name='mark_notification_read'),
    path('notifications/mark-all-read/', views.mark_all_notifications_read, name='mark_all_notifications_read'),
    path('notifications/unread-count/', views.get_unread_notification_count, name='unread_notification_count'),
    path('notifications/recent/', views.get_recent_notifications, name='recent_notifications'),
    path('dashboard-user/alpha-console/', views.project_list, name='alpha_console_projects'),
    path('dashboard-user/alpha-console/create/', views.create_project, name='alpha_console_create'),
    path('dashboard-user/alpha-console/editor/<int:project_id>/', views.editor, name='alpha_console_editor'),
    path('dashboard-user/alpha-console/project/<int:project_id>/save/', views.save_project, name='alpha_console_save'),
    path('dashboard-user/alpha-console/devices/', views.get_available_devices, name='alpha_console_get_devices'),
    path('dashboard-user/alpha-console/connect/', views.connect_device, name='alpha_console_connect_device'),
    path('api/serial/ports/', views.get_serial_ports, name='get_serial_ports'),
    path('api/serial/connect/', views.connect_serial, name='connect_serial'),
    path('api/serial/disconnect/', views.disconnect_serial, name='disconnect_serial'),
    path('api/serial/send/', views.send_to_serial, name='send_to_serial'),
    path('api/serial/read/', views.read_from_serial, name='read_from_serial'),
    path('upload-to-board/', views.upload_to_board, name='upload_to_board'),
    path('api/connect-board/', views.connect_board, name='connect_board'),
    path('upload-to-board/', views.upload_to_board, name='upload_to_board'),
    path('api/', include('mobileapi.urls')),
    


    
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns += [
    # Matches any URL pattern not matched above
    re_path(r'^.*$', views.error_page, name='error-page'),
]