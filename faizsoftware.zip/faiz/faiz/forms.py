from django import forms
from django.forms import inlineformset_factory
from student.models import ObjectiveQuestion, Exam, ExamQuestion, Project, Certificate, student, TrainerDocument, DocumentType

# Existing form for objective questions (unchanged)
class ObjectiveQuestionForm(forms.ModelForm):
    class Meta:
        model = ObjectiveQuestion
        fields = ['question_text', 'option1', 'option2', 'option3', 'option4', 'correct_answer']


# New ExamForm to capture exam details.
class ExamForm(forms.ModelForm):
    class Meta:
        model = Exam
        fields = ['title', 'subject', 'total_marks', 'marks_per_question', 'exam_date', 'student_class']


# Updated ExamQuestionForm.
# Notice that we removed the 'exam' field since the exam instance is set via the formset.
class ExamQuestionForm(forms.ModelForm):
    class Meta:
        model = ExamQuestion
        fields = ['question_text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_answer']


# Create an inline formset for ExamQuestion, linked to the Exam model.
ExamQuestionFormSet = inlineformset_factory(
    Exam, 
    ExamQuestion,
    fields=['question_text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_answer'],
    extra=1,  # Add one empty form for new questions
    can_delete=True,
    widgets={
        'question_text': forms.TextInput(attrs={'class': 'form-control'}),
        'option_a': forms.TextInput(attrs={'class': 'form-control'}),
        'option_b': forms.TextInput(attrs={'class': 'form-control'}),
        'option_c': forms.TextInput(attrs={'class': 'form-control'}),
        'option_d': forms.TextInput(attrs={'class': 'form-control'}),
        'correct_answer': forms.Select(attrs={'class': 'form-control'}),
        'DELETE': forms.CheckboxInput(attrs={'class': 'delete-checkbox'}),
    }
)



ExamQuestionFormSet = inlineformset_factory(
    Exam, ExamQuestion,
    fields=['question_text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_answer'],
    extra=0,  # or set extra forms as needed
    can_delete=True
)


# Existing LoginForm (unchanged)
class LoginForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
    user_type = forms.ChoiceField(
        choices=[('student', 'Student'), ('trainer', 'Trainer')],
        widget=forms.RadioSelect
    )

class StudentProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['title', 'description', 'file']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'ps-input',
                'placeholder': 'Project Title',
                'required': True
            }),
            'description': forms.Textarea(attrs={
                'class': 'ps-textarea',
                'placeholder': 'Project Description',
                'required': True
            }),
            'file': forms.FileInput(attrs={
                'class': 'ps-file-input',
                'accept': "image/*, video/*, .pdf, .zip, .sb3",
                'required': True
            }),
        }

class CertificateRequestForm(forms.ModelForm):
    class Meta:
        model = Certificate
        fields = ['student', 'achievement']

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)  
        super().__init__(*args, **kwargs)
        if user:
            self.fields['student'].queryset = student.objects.filter(user=user)



class DocumentUploadForm(forms.ModelForm):
    class Meta:
        model = TrainerDocument
        fields = ['document_type', 'document_file']
        
    def __init__(self, *args, **kwargs):
        trainer = kwargs.pop('trainer', None)
        super().__init__(*args, **kwargs)
        
        if trainer:
            # Only show document types that haven't been uploaded yet
            uploaded_types = trainer.documents.values_list('document_type', flat=True)
            self.fields['document_type'].queryset = self.fields['document_type'].queryset.exclude(
                id__in=uploaded_types
            )